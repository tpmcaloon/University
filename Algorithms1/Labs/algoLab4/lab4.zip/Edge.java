// To represent the edges in the graph.
public class Edge {
  public Vertex from, to;
  public int weight;
  
  public Edge(Vertex _from, Vertex _to, int _weight) {
    from = _from;
    to = _to;
    weight = _weight;
  }
}
