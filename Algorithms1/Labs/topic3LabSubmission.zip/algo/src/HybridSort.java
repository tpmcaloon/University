import java.util.Arrays;

public class HybridSort {

    public static void main(String[] args) {

        int[][] Tests = {
                {},
                {9,8,7,6},
                {6, 2, 8, 5, 7, 5, 0, 2},
                {2,2,2,2,2,2,2,2},
                {4, -7, 2, 1, 0, 2, 4, 2, -3, 3, -3, 7, -2, 7, 7},
                {-2, -2, -4, -9, -1, -6, -1, -14, -3, -15, -12, -12, -2, -8, -9},
        };
        for (int[] A: Tests) {
            try {
                System.out.println("Given array: " + Arrays.toString(A));
                hybridSort(A); //change the name of function if necessary
                System.out.println("Array sorted: " + Arrays.toString(A));
                System.out.println();
            }   catch (Exception e) {
                System.out.println("Error for array: " + Arrays.toString(A));
                System.out.println(e);
            }
        }
    }


    private static int[] selectionSort(int[] A) {
        // One by one move boundary of unsorted subarray
        for (int i = 0; i < A.length - 1; i++) {
            //System.out.println(Arrays.toString(array));

            // Find the minimum element in unsorted array
            int minIndex = i;
            for (int j = i + 1; j < A.length; j++) {
                if (A[j] < A[minIndex]) {
                    minIndex = j;
                }
            }

            // Swap the found minimum element with the first
            // element
            int temp = A[minIndex];
            A[minIndex] = A[i];
            A[i] = temp;
        }
        return A;
    }

    private static int[] bubbleSort(int[] A) {
        int n = A.length - 1;
        boolean toSwap = true;
        int temp;
        while (toSwap) {
            toSwap = false;
            for (int i = 0; i < n; i++) {
                if (A[i] > A[i + 1]) {
                    temp = A[i];
                    A[i] = A[i + 1];
                    A[i + 1] = temp;
                    toSwap = true;
                }
            }
            n--;
        }
        return A;
    }

    public static void hybridSort(int[] A) {
        while (0 < A.length) {
            if (A.length < A.length+1) {
                bubbleSort(A);
                selectionSort(A);
                break;
            }
        }
    }
}
