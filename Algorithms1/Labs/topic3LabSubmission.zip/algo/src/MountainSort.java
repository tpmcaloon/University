import java.util.Arrays;
import java.util.*; //please, do not forget to include this line

public class MountainSort {
    public static void main(String[] args) {

        int[][] Tests = {
                {},
                {6, 2, 8, 5, 7, 5, 0, 2},
                {2,2,2,2,2,2,2,2},
                {4, -7, 2, 1, 0, 2, 4, 2, -3, 3, -3, 7, -2, 7, 7},
                {-2, -2, -4, -9, -1, -6, -1, -14, -3, -15, -12, -12, -2, -8, -9},
        };
        for (int[] A: Tests) {
            try {
                System.out.println("Given array: " + Arrays.toString(A));
                A = MountainSort(A); //change the name of function if necessary
                System.out.println("Array sorted: " + Arrays.toString(A));
                System.out.println();
            } catch (Exception e) {
                System.out.println("Error for array: "+ Arrays.toString(A));
                System.out.println(e);
            }
        }
    }


    public static int[] MountainSort(int[] A) {

        int temp = 0;

        int a[] = Arrays.copyOfRange(countingSort(A), 0, A.length/2);
        int b[] = Arrays.copyOfRange(countingSort(A), (A.length/2), A.length);

        for (int i = 0; i < b.length; i++) {
            for (int j = i + 1; j < b.length; j++) {
                if (b[i] < b[j]) {
                    temp = b[i];
                    b[i] = b[j];
                    b[j] = temp;
                }
            }
        }

        int[] result = new int[a.length + b.length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);

        return result;
    }

    private static int[] countingSort(int[] array) {
        if (array.length == 0) {
            return new int[0];
        } else {

            int max = Arrays.stream(array).max().getAsInt();
            int min = Arrays.stream(array).min().getAsInt();

            int range = max - min + 1;
            int count[] = new int[range];

            for (int i = 0; i < array.length; i++) {
                count[array[i] - min]++;
            }

            int AIndex = 0;
            for (int i = 0; i < count.length; i++) {
                while (0 != count[i]) {
                    array[AIndex] = i + min;
                    count[i] -= 1;
                    AIndex += 1;
                }
            }
            return array;
        }
    }
}