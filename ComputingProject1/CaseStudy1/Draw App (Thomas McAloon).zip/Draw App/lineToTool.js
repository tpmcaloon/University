function LineToTool(){
	this.icon = "assets/lineTo.jpg";
	this.name = "LineTo";

	var startMouseX = -1;
	var startMouseY = -1;
	var drawing = false; //Stops the line from neing drawn unless the mouse is prssed

	this.draw = function(){

		if(mouseIsPressed){
			if(startMouseX == -1){
				startMouseX = mouseX;
				startMouseY = mouseY;
				drawing = true; // Changes drawing state to true
				loadPixels(); // Keeps the line drawn after the user has released the mouse
			}

			else{
				updatePixels(); // Allows only one line to be drawn, opposed to a new line every frame while the mouse is pressed
				line(startMouseX, startMouseY, mouseX, mouseY); // Draws the line using the Mouse X & Mouse Y Position
			}

		}

		else if(drawing){
			drawing = false; //Changes drawing state to false
			startMouseX = -1;
			startMouseY = -1;
		}
	};


}
