function Spectrum() {
	this.name = "spectrum";

	this.draw = function() {
		push();
		var spectrum = fourier.analyze();
		noStroke();


		fill(0,i,0)
		for (var i = 0; i< spectrum.length; i++){
			var colour = map(spectrum[i], 255 *spectrum[i], 0, 255 / spectrum[i], 127);
            fill(spectrum[i], colour, 0);

            var y = map(i, 0, height/2, 0, spectrum.length);
            var h = map(spectrum[i], 0, 255, 0, width);
            rect(0, y, h, width/spectrum.length);
          }
	
		pop();
	};
}