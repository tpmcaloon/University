import "./sidebar.css";
import {
  Timeline,
  PermIdentity,
  Home,
  Whatshot,
  SportsSoccer,
  ExitToApp,
} from "@material-ui/icons";
import { Link } from "react-router-dom";

const Sidebar = ({handleLogout}) => {
  return (
    <div className="sidebar">
      <div className="sidebarWrapper">
        <div className="sidebarMenu">
          <ul className="sidebarList">
            
            <Link to="/" className="link">
            <li className="sidebarListItem">
              <Home className="sidebarIcon" />
              Home
            </li>
            </Link>
            
            <Link to="dashboard" className="link">
            <li className="sidebarListItem">
              <Timeline className="sidebarIcon" />
              Dashboard
            </li>
            </Link>
            
            <Link to="manageFixtures" className="link">
            <li className="sidebarListItem">
              <SportsSoccer className="sidebarIcon" />
              Manage Fixtures
            </li>
            </Link>
            
            <Link to="myTeam" className="link">
              <li className="sidebarListItem">
                <PermIdentity className="sidebarIcon" />
                My Team
              </li>
            </Link>
            
            <Link to="findAChallenge" className="link">
              <li className="sidebarListItem">
                <Whatshot className="sidebarIcon" />
                Find a Challenge
              </li>
            </Link>
            
            <li className="sidebarListItem" onClick={handleLogout}>
                <ExitToApp className="sidebarIcon" />
                Logout
              </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;