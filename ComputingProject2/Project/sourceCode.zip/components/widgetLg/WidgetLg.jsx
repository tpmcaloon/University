import "./widgetLg.css";

export default function WidgetLg() {
  const Button = ({ type }) => {
    return <button className={"widgetLgButton " + type}>{type}</button>;
  };
  return (
    <div className="widgetLg">
      <h3 className="widgetLgTitle">Upcoming Fixtures</h3>
      <table className="widgetLgTable">
        <tr className="widgetLgTr">
          <th className="widgetLgTh">Team</th>
          <th className="widgetLgTh">Date</th>
          <th className="widgetLgTh">Current Position</th>
          <th className="widgetLgTh">Form</th>
        </tr>
        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">Barnet</span>
          </td>
          <td className="widgetLgDate">2 May 2022</td>
          <td className="widgetLgPosition">8th</td>
          <td className="widgetLgForm">
            <Button type="L-L-L-D-W" />
          </td>
        </tr>
        
        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">Highgate</span>
          </td>
          <td className="widgetLgDate">10 May 2022</td>
          <td className="widgetLgPosition">2nd</td>
          <td className="widgetLgForm">
            <Button type="W-W-W-L-W" />
          </td>
        </tr>

        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">Finchley</span>
          </td>
          <td className="widgetLgDate">17 May 2022</td>
          <td className="widgetLgPosition">4th</td>
          <td className="widgetLgForm">
            <Button type="L-W-L-D-D" />
          </td>
        </tr>

        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">New Cross</span>
          </td>
          <td className="widgetLgDate">23 May 2022</td>
          <td className="widgetLgPosition">3rd</td>
          <td className="widgetLgForm">
            <Button type="L-W-W-D-W" />
          </td>
        </tr>

        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">Lewisham</span>
          </td>
          <td className="widgetLgDate">3 June 2022</td>
          <td className="widgetLgPosition">5th</td>
          <td className="widgetLgForm">
            <Button type="L-L-W-D-W" />
          </td>
        </tr>

        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">Peckham</span>
          </td>
          <td className="widgetLgDate">10 June 2022</td>
          <td className="widgetLgPosition">7th</td>
          <td className="widgetLgForm">
            <Button type="L-L-L-D-D" />
          </td>
        </tr>

        <tr className="widgetLgTr">
          <td className="widgetLgFixtures">
            <img
              src="https://images.pexels.com/photos/4172933/pexels-photo-4172933.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt=""
              className="widgetLgImg"
            />
            <span className="widgetLgName">Potters Bar</span>
          </td>
          <td className="widgetLgDate">16 June 2022</td>
          <td className="widgetLgPosition">1st</td>
          <td className="widgetLgForm">
            <Button type="W-W-W-W-W" />
          </td>
        </tr>
      </table>
    </div>
  );
}
