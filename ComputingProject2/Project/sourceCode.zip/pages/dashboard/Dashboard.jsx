import Chart from "../../components/chart/Chart";
import FeaturedInfo from "../../components/featuredInfo/FeaturedInfo";
import "./dashboard.css";
import 'intro.js/introjs.css';
import { Steps } from 'intro.js-react';
import React, {useState} from 'react';

import { userData, playerData, fixtureData } from "../../dummyData";

import InteractiveTable from 'react-interactive-table';


export default function Dashboard() { 
  const [enabled,setEnabled] = useState(true);
  const [initialStep,setInitialStep] = useState(0);
  
  const onExit = () => {
    setEnabled(false)
  }

  const steps = [
    {
      element: '#home',
      intro: 'Welcome to your Rivals Dashboard'
    },
    {
      element: '#widgets',
      intro: 'These are widgets designed to show relevant data about your team & Players'
    },
    {
      element: '#chart',
      intro: 'This chart is designed to show you how your team has performed over the last 12 months!'
    },
    {
      element: '#playerTable',
      intro: 'You can use this table to view the players in the club!',
      position: 'right',
    },
    {
      element: '#teamTable',
      intro: 'You can use this table to view upcomming fixtures',
    },
];
  return (
    <div className="home">
      <h1 className='myTeamHeading'>Dashboard</h1>
      
      <Steps
          enabled={enabled}
          steps={steps}
          initialStep={initialStep}
          onExit={onExit}
        />
        <div id="widgets">
    <FeaturedInfo />
    </div>
    <div id="chart">
    <Chart data={userData} title="Games Won" grid dataKey="Won"/>
    </div>
    <div className="homeWidgets">
      <div className="team-table" id="playerTable">
        <h1 className="team-table-title">Your Players</h1>
        <InteractiveTable
        tableStyles={'./dashboard.css'}
        dataList={playerData} 
        columns={
          {
            firstname: {
            alias: 'First Name',
            sortable: true,
            active: false,
            sortingKey: 'firstname'
            },
            
            lastname: {
            alias: 'Last Name',
            sortable: true,
            active: false,
            sortingKey: 'lastname'
            },

            position: {
            alias: 'Position',
            sortable: true,
            active: false,
            sortingKey: 'position'
            },

            available: {
            alias: 'Available',
            sortable: true,
            active: true,
            sortingKey: 'available'
            },

            goals: {
            alias: 'Goals',
            sortable: true,
            active: false,
            sortingKey: 'goals'
            },

            assists: {
            alias: 'Assists',
            sortable: true,
            active: false,
            sortingKey: 'assists'
            },

            cleansheets: {
            alias: 'Clean Sheets',
            sortable: true,
            active: false,
            sortingKey: 'cleansheets'
            },
          }
        }
        paging={{
          maxRows: 8,
          prevBtn: 'Prev',
          nextBtn: 'Next',
          showAll: true,
          showAllText: 'Show All',
          joinPages: true
        }}
        />
            <FeaturedInfo />
            </div>

        <div className="fixture-table" id="teamTable">
            <h1 className="fixture-table-title">Upcomming Fixtures</h1>
            <InteractiveTable
            tableStyles={'./myTeam.css'}
            dataList={fixtureData} 
            columns={
                {
                teamName: {
                    alias: 'Team Name',
                    sortingKey: 'teamName'
                },

                postalCode: {
                    alias: 'Post Code',
                    sortingKey: 'postalCode'
                },

                form: {
                    alias: 'Form',
                    sortingKey: 'form'
                },

                matchDate: {
                    alias: 'Match Date',
                    sortingKey: 'matchDate'
                }
            }
        }
        paging={{
              maxRows: 8,
              prevBtn: 'Prev',
              nextBtn: 'Next',
              showAll: true,
              showAllText: 'Show All',
              joinPages: true
          }}
            />
          <FeaturedInfo />
        </div>
      </div>
    </div>
  );
}