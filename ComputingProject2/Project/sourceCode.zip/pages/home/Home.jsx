import "./home.css"

import { Link } from "react-router-dom";

import joinATeam from './joinATeam.png'
import makeATeam from './makeATeam.png'
import dashboard from './dashboard.png'

export default function Home() {
  return (
    <div className="home-wrapper">      
      <div class='card-section'>
      <h1 className="homeHeading1">Welcome to <span className="greenHeading">Rivals!</span></h1>
      <h3 className="homeHeading3">Welcome to <span className="greenHeading">Rivals</span>, lets get started. The quckets way to get started is by <span className="greenHeading">Joining a team</span> but if you want to start from humble beginnings you can <span className="greenHeading">Create your own team!</span></h3>

      <Link to="joinATeam" className="link">
        <div class='card-box'>
        <img  src={joinATeam}  alt="Login" width="450" />
          <div class='card-text'>
          <a href='./joinATeam'><button class='card-btn'>Join a Team</button></a>
          </div>
        </div>
      </Link>
        
        <Link to="makeATeam" className="link">
        <div class='card-box'>
        <img  src={makeATeam}  alt="Login" width="450" />
          <div class='card-text'>
          <a href='./dashboard'><button class='card-btn'>Make a Team</button></a>
          </div>
        </div>
        </Link>

        <Link to="dashboard" className="link">
        <div class='card-box'>
          <img src={dashboard}  alt="Login" width="450" />
          <div class='card-text'>
          <button class='card-btn'>Dashboard</button>
          </div>
        </div>
        </Link>
      </div>
    </div>
    )
  }