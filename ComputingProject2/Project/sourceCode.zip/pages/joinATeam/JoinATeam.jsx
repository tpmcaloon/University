import React, { useState } from 'react';

import { db } from '../../utils/fire';
// import { columns, rows, teamData } from '../../dummyData';
import Lottie from 'react-lottie';
import animationData from '../../lotties/join-a-team.json';
import InteractiveTable from 'react-interactive-table';

import "./joinATeam.css";

const JoinATeam = () => {
    
    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData: animationData,
        rendererSettings: {
            preserveAspectRatio: "xMidYMid slice"
        }
    }
    
    const [teamData, setTeamData] = useState([])

    // Start the fetch operation as soon as
    // the page loads
    window.addEventListener('load', () => {
        Fetchdata();
    });

    // Fetch the required data using the get() method
    const Fetchdata = ()=>{
        db.collection("MakeATeam").get().then((querySnapshot) => {
            // Loop through the data and store
            // it in array to display
            querySnapshot.forEach(element => {
                var data = element.data();
                setTeamData(arr => [...arr , data]);
            });
        })
    }
    return (
        <div className="home-wrapper">
            <center>
            <h1>Join A Team</h1>
                <Lottie className='test'
                options={defaultOptions}
                height={400}
                width={400}
                />
            </center>
        {
            teamData.map((data) => (
                <InteractiveTable
                tableStyles={'./myTeam.css'}
                dataList={data} 
                columns={
                    {
                    teamName: {
                        alias: 'Team Name',
                        sortingKey: 'teamName'
                    },
    
                    address: {
                        alias: 'Address',
                        sortingKey: 'address'
                    },
    
                    postalCode: {
                        alias: 'Post Code',
                        sortingKey: 'postalCode'
                    },
    
                    form: {
                        alias: 'Form',
                        sortingKey: 'form'
                    },
    
                    numOfPlayers: {
                        alias: 'Number of Players',
                        sortingKey: 'numOfPlayers'
                    },
    
                    lookingForPlayers: {
                        alias: 'Looking for Players',
                        sortingKey: 'lookingForPlayers'
                    },
                }
              }
                paging={{
                    maxRows: 8,
                    prevBtn: 'Prev',
                    nextBtn: 'Next',
                    showAll: true,
                    showAllText: 'Show All',
                    joinPages: true
                }}
              /> 
            )
            )
        }
        </div>
    );
}


export default JoinATeam;