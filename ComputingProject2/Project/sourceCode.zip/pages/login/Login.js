import React from 'react';
import './Login.css';
import loginImage from './269.svg';

const Login = (props) => {

  const { 
    email, 
    setEmail, 
    password, 
    setPassword, 
    handleLogin, 
    handleSignUp, 
    hasAccount, 
    setHasAccount, 
    emailError, 
    passwordError 
  } = props;

  return(
    <div className="login-wrapper">
      <div class="loginContainer" id="loginContainer">
        {/* <!-- sign in page --> */}
        <div class="form-container sign-in-container">
          <section>
            <div class="form__input-group">
              <label for="email">Email: </label>
              <input 
                type="text" 
                autoFocus 
                required 
                value={email} 
                onChange={e => setEmail(e.target.value)} 
              />
              <p className='errorMsg'>{emailError}</p>
            </div>
            <div class="form__input-group">
              <label for="pass">Password: </label>
              <input 
                type="password" 
                required 
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
              <p className='errorMsg'>{passwordError}</p>
            </div>
            <div class="form__input-group">
              {hasAccount ? (
                <>
                  <button onClick={handleLogin} class="form__button"> Sign In</button>
                  <p>
                    Don't have an account? 
                    <span className='loginSpan' onClick={() => setHasAccount(!hasAccount)}> Sign Up</span>
                  </p>
                </>
                ) : (
                <>
                  <button onClick={handleSignUp} class="form__button">Sign Up</button>
                  <p>
                    Have an account? 
                    <span className='loginSpan'onClick={() => window.location.reload()}>Sign In</span>
                  </p>
                </>
              )}
            </div>
          </section>
        </div>
        
        <div class="overlay-container">
          <div class="overlay">	
            <div class="overlay-panel overlay-right">
              <h1>Welcome to Rivals!</h1>
              <img  src={loginImage}  alt="Login" width="350" height="350"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Login;