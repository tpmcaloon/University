import React from 'react';
import { db } from '../../utils/fire';
import './makeATeam.css';
import Lottie from 'react-lottie';
import animationData from '../../lotties/make-a-team.json';

const MakeATeam = () => {

  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice"
    }
  }

  const handleSubmit = (event) => {
    event.preventDefault();

    const elementsArray =[...event.target.elements];

    const formData = elementsArray.reduce((accumulator, currentValue) => {
      if(currentValue.id) {
        accumulator[currentValue.id] = currentValue.value
      }
      return accumulator;
    }, {});
    console.log(formData);

    db.collection("MakeATeam").add({formData});
  };

  return(
    <div className='home-wrapper'>
    <div className="login-wrapper">
      <div class="loginContainer" id="loginContainer">
        <div class="form-container sign-in-container">
          <section>
            <form onSubmit={handleSubmit}>
            <div class="form__input-group">
              <label id="teamName">Team Name: </label>
              <input 
                type="text" 
                required 
                id='teamName' 
                placeholder='Team Name...'
              />
            </div>

            <div class="form__input-group">
              <label id="abbreviation">Abbreviation: </label>
              <input 
                type='text'
                required 
                id='abbrieviation'
                placeholder='Abreviation...'
              />
            </div>

            <div class="form__input-group">
              <label id="badge">Badge: </label>
              <input 
                type="file" 
                accept="image/*"
                id='badge' 
              />
            </div>

            <div class="form__input-group">
              <label id="postcode">Postcode: </label>
              <input 
                type="text"
                autocomplete="shipping street-postcode"
                required 
                id='postcode'
                placeholder='Postcode...'
              />
            </div>

            <div class="form__input-group">
              <label id="address">Address: </label>
              <input 
                type="text" 
                autocomplete="shipping street-address"
                required 
                id='address' 
                placeholder='Address...'
              />
            </div>

            <div class="form__input-group">
              <label id='lookingForPlayers'>Looking for Players: </label>
              <input 
                type="radio" 
                required 
                id='lookingForPlayers'
              />
            </div>
            <div class="form__input-group">
                <button class="form__button"> Submit</button>
            </div>
            </form>
          </section>
        </div>
        
        <div class="overlay-container">
          <div class="overlay">	
            <div class="overlay-panel overlay-right">
              <h1>Make your Team!</h1>
              <Lottie 
              options={defaultOptions}
              height={400}
              width={400}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  )
}

export default MakeATeam;