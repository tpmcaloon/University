import React from 'react';
import InteractiveTable from 'react-interactive-table';
import { fixtureData } from "../../dummyData";

import "./manageFixtures.css";

export default class ManageFixtures extends React.Component {
    
    render () {

return ( 
    <div className='manageFixtures-Table'>
        <h1 className='manageFixturesHeading'>Manage Fixtures</h1>
                <InteractiveTable
            tableStyles={'./myTeam.css'}
            dataList={fixtureData} 
            columns={
                {
                teamName: {
                    alias: 'Team Name',
                    sortingKey: 'teamName'
                },

                postalCode: {
                    alias: 'Post Code',
                    sortingKey: 'postalCode'
                },

                form: {
                    alias: 'Form',
                    sortingKey: 'form'
                },

                matchDate: {
                    alias: 'Match Date',
                    sortingKey: 'matchDate'
                }
            }
        }
        searching={{
            active: true,
            searchPlaceholder: 'Search...',
            searchKeys: ['teamName', 'postcode', 'form', 'matchDate']
        }}
            paging={{
                maxRows: 8,
                prevBtn: 'Prev',
                nextBtn: 'Next',
                showAll: true,
                showAllText: 'Show All',
                joinPages: true
            }}
            /> 
            </div>  
        )
    }
}