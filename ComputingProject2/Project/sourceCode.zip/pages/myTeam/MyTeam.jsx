import React from 'react';
import InteractiveTable from 'react-interactive-table';
import FeaturedInfo from '../../components/featuredInfo/FeaturedInfo';
import { playerData } from "../../dummyData";

import "./myTeam.css";

export default class MyTeam extends React.Component {
    
    render () {

return ( 
    <div className='myTeam-Table'>
        <h1 className='myTeamHeading'>My Team</h1>
        <FeaturedInfo />
                <InteractiveTable
                    tableStyles={'./myTeam.css'}
                    dataList={playerData} 
                    columns={
                        {
                            firstname: {
                                alias: 'First Name',
                                sortable: true,
                                active: false,
                                sortingKey: 'firstname'
                            },

                            lastname: {
                                alias: 'Last Name',
                                sortable: true,
                                active: false,
                                sortingKey: 'lastname'
                            },

                            position: {
                                alias: 'Position',
                                sortable: true,
                                active: false,
                                sortingKey: 'position'
                            },

                            available: {
                                alias: 'Available',
                                sortable: true,
                                active: true,
                                sortingKey: 'available'
                            },

                            goals: {
                                alias: 'Goals',
                                sortable: true,
                                active: false,
                                sortingKey: 'goals'
                            },

                            assists: {
                                alias: 'Assists',
                                sortable: true,
                                active: false,
                                sortingKey: 'assists'
                            },

                            cleansheets: {
                                alias: 'Clean Sheets',
                                sortable: true,
                                active: false,
                                sortingKey: 'cleansheets'
                            },
                        }
                    }
                    searching={{
                        active: true,
                        searchPlaceholder: 'Search...',
                        searchKeys: ['firstName', 'lastname', 'position', 'available', 'goals', 'assists', 'cleansheets']
                    }}
                    paging={{
                        maxRows: 8,
                        prevBtn: 'Prev',
                        nextBtn: 'Next',
                        showAll: true,
                        showAllText: 'Show All',
                        joinPages: true
                    }}
                /> 
            </div>  
        )
    }
}