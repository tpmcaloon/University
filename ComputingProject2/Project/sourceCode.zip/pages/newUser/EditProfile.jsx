import React from 'react';
import { db } from '../../utils/fire';
import "./editProfile.css";
import Lottie from 'react-lottie';
import animationData from '../../lotties/editProfile.json';
import { Link } from 'react-router-dom';


const editProfile = () => {

  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice"
    }
  }
  
  const handleSubmit = (event) => {
    event.preventDefault();

    const elementsArray =[...event.target.elements];

    const formData = elementsArray.reduce((accumulator, currentValue) => {
      if(currentValue.id) {
        accumulator[currentValue.id] = currentValue.value
      }
      return accumulator;
    }, {});
    console.log(formData);

    db.collection("userProfile").add({formData});
  };

  return (
    <div className='home-wrapper'>
    <div className="login-wrapper">
      <div class="loginContainer" id="loginContainer">
        <div class="form-container sign-in-container">
          <section>
            <form onSubmit={handleSubmit}>
            <div class="form__input-group">
              <label id="firstName">First Name: </label>
              <input 
                type="text" 
                required 
                id='firstName' 
                placeholder='First Name...'
              />
            </div>

            <div class="form__input-group">
              <label id="lastName">Last Name: </label>
              <input 
                type='text'
                required 
                id='lastName'
                placeholder='Last Name...'
              />
            </div>

            <div class="form__input-group">
              <label id="address">address: </label>
              <input 
                type='text'
                required 
                autocomplete="shipping street-address"
                id='address'
                placeholder='Address...'
              />
            </div>

            <div class="form__input-group">
              <label id="phone">Phone: </label>
              <input 
                type="text"
                required 
                id='phone'
                placeholder='Phone...'
              />
            </div>

            <div class="form__input-group">
            <label id='gender'>Gender: </label>
            <select className="gender" name="gender" id="gender">
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div class="form__input-group">
              <label id='available'>Available: </label>
              <select className="available" name="available" id="available">
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>

            <div class="form__input-group">
            <label id='position'>Position: </label>
              <select className="position" name="position" id="position">
                <option value="ST">ST</option>
                <option value="CF">CF</option>
                <option value="LW">LW</option>
                <option value="LM">LM</option>
                <option value="RW">RW</option>
                <option value="RM">RM</option>
                <option value="CAM">CAM</option>
                <option value="CM">CM</option>
                <option value="CDM">CDM</option>
                <option value="CB">CB</option>
                <option value="LB">LB</option>
                <option value="RB">RB</option>
                <option value="GK">GK</option>
              </select>
            </div>


            <div class="form__input-group">
                <button class="form__button">Save</button>
                <Link to="dashboard" className="link"><button class="form__button">Exit</button></Link>
            </div>
            </form>
          </section>
        </div>
        
        <div class="overlay-container">
          <div class="overlay">	
            <div class="overlay-panel overlay-right">
              <h1>Edit your profile!</h1>
              <Lottie 
              options={defaultOptions}
              height={400}
              width={400}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  )
}

export default editProfile;