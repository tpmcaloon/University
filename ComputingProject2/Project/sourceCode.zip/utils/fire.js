import firebase from 'firebase/compat/app';
import 'firebase/compat/auth'; //v9
import 'firebase/compat/firestore';
import 'firebase/firestore/';


const firebaseConfig = {
    apiKey: "AIzaSyB7sc2AqpGPkdpwtq-b3-uu2EESOFApw7s",
    authDomain: "rivals-344001.firebaseapp.com",
    databaseURL: "https://rivals-344001-default-rtdb.firebaseio.com",
    projectId: "rivals-344001",
    storageBucket: "rivals-344001.appspot.com",
    messagingSenderId: "592422023317",
    appId: "1:592422023317:web:f6ef03dc23872c0b312b9c",
    measurementId: "G-DV55YYFNCZ"
};

const fire = firebase.initializeApp(firebaseConfig);
const db = fire.firestore();


export { fire, db } ;