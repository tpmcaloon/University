import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.*;
public class JWord extends JFrame implements ActionListener {

    private static JLabel stats;
    private static JTextField userText1;
    private static JLabel[] labels;

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_GREEN = "\u001B[32m";

    static String[] gameDictionary;
    static int tries;
    static char[] input;
    static long startTime;
    static char[] answer;
    static boolean done;
    static String answerChosen;

	public static void main(String[] args) {

        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(220, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("JWord");
        frame.setLocationRelativeTo(null);
        frame.add(panel);

        panel.setLayout(null);
        JLabel title = new JLabel("JWord: ");
        title.setBounds(10, 20, 80, 25);
        panel.add(title);

        panel.setLayout(null);
        stats = new JLabel("Type a five letter word");
        stats.setBounds(10, 50, 180, 25);
        panel.add(stats);

        userText1 = new JTextField();
        userText1.addActionListener(new JWord());
        userText1.setBounds(40, 80, 80, 25);
        panel.add(userText1);

        JButton button = new JButton("Enter");
        button.setBounds(100, 20, 80, 25);
        button.addActionListener(new JWord());
        panel.add(button);

        labels = new JLabel[6];
        for (int i = 0; i < 6; i++) {
            labels[i] = new JLabel("<html><font size='5' color=blue> ----- </font> <font");
            labels[i].setBounds(44, 80 + (i * 25), 80, 25);
            panel.add(labels[i]);
        }

        frame.setVisible(true);

        StartJWord(); //gets the answer work and starts the timer
    }



    public static void StartJWord() {

//        //    //load in the two word lists
//        try{
//            Scanner in_dict  = new Scanner(new File("gameDictionary.txt"));
//            while(in_dict.hasNext()){
//                dictionary.add(in_dict.next());
//            }
//
//            Scanner in_targets = new Scanner(new File("targetWords.txt"));
//            while(in_targets.hasNext()){
//                targetWords.add(in_targets.next());
//            }
//            in_dict.close();
//            in_targets.close();
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
////
////    //use this method for selecting a word. It's important for marking that the word you have selected is printed out to the console!
//    public static String getTarget(){
//        Random r = new Random();
//        String target = targetWords.get(r.nextInt(targetWords.size()));
//        //don't delete this line.
//        System.out.println(target);
//        return target;
//    }

        gameDictionary = new String[12947];
        try {
            File myObj = new File("gameDictionary.txt");
            Scanner myReader = new Scanner(myObj);
            int indexCounter = 0;
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                //add data to the array
                gameDictionary[indexCounter] = data;
                indexCounter++;
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        startTime = System.currentTimeMillis();
        tries = 0;
        System.out.println("JWord: Type A Five Letter Word");
        answerChosen = ReturnRandomWord();
        answer = new char[5];
        for (int i = 0; i < 5; i++ ) answer[i] = answerChosen.charAt(i);

        input = new char[5];
    }
    
    public static void EndJWord() {
        System.out.println("JWord: The Answer Was: " + answerChosen);
        System.out.println("JWord: You Found The Answer in " + ((System.currentTimeMillis() - startTime) / 1000) + " seconds and " + tries + " tries.");

        userText1.setEnabled(false);
        userText1.setVisible(false);

        if (!done) stats.setText("<html><font size='1' color=red> " + "The Answer Was: " + answerChosen + ". You wasted \n " + ((System.currentTimeMillis() - startTime) / 1000) + " seconds (:" + "</font> <font");
        else  stats.setText("<html><font size='1' color=green> " + "You Found The Answer in \n " + ((System.currentTimeMillis() - startTime) / 1000) + " seconds and " + tries + " tries." + "</font> <font");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub // if the button is pressed
        EnterWord();
    }

    public static void EnterWord(){ //if It's good, actually submit the word for checking
        if ( IsAValidWord(userText1.getText(), gameDictionary) ) ButtonPressed();
        else System.out.println("JWord: That is not a valid word");
    }

    public static void ButtonPressed(){
        userText1.setBounds(40, 80 + ((tries + 1) * 25), 80, 25);

        String userInput = userText1.getText();
        int[] colorOfLetters = PlayJWord(userInput);

        done = true;
        for (int i : colorOfLetters) {
            if (i != 2) {
                done = false;
                break;
            }
        }
        if (done || tries > 5) EndJWord();

        String[] numsToColors = new String[5];
        for (int i = 0; i < 5; i++) {
            if (colorOfLetters[i] == 0) numsToColors[i] = "black";
            else if (colorOfLetters[i] == 1) numsToColors[i] = "orange";
            else if (colorOfLetters[i] == 2) numsToColors[i] = "green";
        }

        System.out.println("Set colors to " + numsToColors[0] + " " + numsToColors[1] + " " + numsToColors[2] + " " + numsToColors[3] + " " + numsToColors[4] + " User Input was" + userInput + " answer was " + answerChosen + " work on word is " + new String(answer));
        String finalString = (
        "<html><font size='5' color=" + numsToColors[0] + "> " + userInput.charAt(0) + "</font> <font            " + 
        "<html><font size='5' color=" + numsToColors[1] + "> " + userInput.charAt(1) + "</font> <font            " + 
        "<html><font size='5' color=" + numsToColors[2] + "> " + userInput.charAt(2) + "</font> <font            " + 
        "<html><font size='5' color=" + numsToColors[3] + "> " + userInput.charAt(3) + "</font> <font            " + 
        "<html><font size='5' color=" + numsToColors[4] + "> " + userInput.charAt(4) + "</font> <font            ");
        setNextLabel(finalString);

        userText1.setText(""); //set the text box to "" after all the logic is done
    }

    public static int[] PlayJWord(String InputJWord) {
        done = false;
        tries++;

        String R1 = InputJWord.toLowerCase();//String R1 = s.nextLine().toLowerCase();

        //check if it is 5 letters and is a possible word
        if (!IsAValidWord(R1, gameDictionary)) {
            System.out.println("wasn't a good word");
        } else {
            for (int i = 0; i < 5; i++ ) { //puts the inputWord into a char[]
                input[i] = R1.charAt(i);
            }
        }
//just reset answer every time
        for (int i = 0; i < 5; i++ ) answer[i] = answerChosen.charAt(i);
        return ReturnColorOfLetters(input, answer);
    }

    public static void setNextLabel(String string){
        labels[tries - 1].setText(string);
    }

    public static int[] ReturnColorOfLetters(char[] inputWord, char[] correctWord) {
        int[] colorForLetter = new int[5]; //0 is grey, yellow is 1, green is 2

        for (int i = 0; i < 5; i++) { //check for any correct position+letter (green)
            if (inputWord[i] == correctWord[i]) {
                correctWord[i] = '-';
                colorForLetter[i] = 2;
            }
        }

        for (int j = 0; j < 5; j++) { //check for any correct letter (yellow)
            for (int k = 0; k < 5; k++){
                if (inputWord[j] == correctWord[k] && colorForLetter[j] != 2) {
                    //if that letter is not already green and matches some others letter
                    colorForLetter[j] = 1;
                    correctWord[k] = '-';
                }
            }
        }

        for (int m = 0; m < 5; m++) {
            if (colorForLetter[m] == 0) System.out.print(inputWord[m]);
            if (colorForLetter[m] == 1) System.out.print(ANSI_YELLOW + inputWord[m] + ANSI_RESET);
            if (colorForLetter[m] == 2) System.out.print(ANSI_GREEN + inputWord[m] + ANSI_RESET);
        }

        System.out.println();
        return colorForLetter;
    }

    public static boolean IsAValidWord(String input, String[] possibleWords) {
        if (input.length() < 5) {
            System.out.println("JWord: The Word You Entered Was Not Long Enough");
            return false;
        }
        for (String string : possibleWords) {
            if (string.equals(input)) {
                return true;
            }
        }
        return false;
    }

    public static String ReturnRandomWord(){

        String[] answerList = new String[2315];
        try {
            File targetWords = new File("targetWords.txt");
            Scanner myReader = new Scanner(targetWords);
            int indexCounter = 0;
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                //add data to the array
                answerList[indexCounter] = data;
                indexCounter++;
            }
            myReader.close();   
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        return answerList[(int)(Math.random() * (answerList.length - 1))]; //returns a random word from this large list
    }
}