
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.ArrayList;


public class BookCollection {
    private ArrayList<Book> books = new ArrayList<Book>();

    //2, complete constructor that takes a string path (the BookList file name) load the books from BookList into the books arrayList
    //When complete books should have 100 items. Make sure you don't include the header row!
    BookCollection(String path) {
        try {
            File file = new File(path);
            Scanner scanner = new Scanner(new FileInputStream(file));
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                Book book = new Book(parts[0], parts[1], Long.parseLong(parts[2]), Integer.parseInt(parts[3]), Integer.parseInt(parts[4]), Integer.parseInt(parts[5]));
                books.add(book);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println(e);
        }
    }

    //3, Return a HashSet of all the authors in the book list
    public HashSet<String> getAuthors() {
        HashSet<String> authors = new HashSet<>();
        for (Book book : books) {
            authors.add(book.getAuthor());
        }
        return authors;
    }

    //4, return an arrayList of books with more than 750 pages
    public ArrayList<Book> getLongBooks() {
        ArrayList<Book> longBooks = new ArrayList<>();
        for (Book book : books) {
            if (book.getPages() > 750)
                longBooks.add(book);
        }
        return longBooks;
    }

    //5, return the book if the given title is in the list.
    public Book getBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equals(title))
                return book;
        }
        return null;
    }

    //6, return an array of the 10 most popular books (That is those that currently have most copies on loan)
    public Book[] mostPopular() {
        ArrayList<Book> popularBooks = new ArrayList<>();
        int count = 10;
        for (Book book : books) {
            for (int i = 0; i < count; i++) {
                if(popularBooks.size() <= i){
                    popularBooks.add(book);
                    break;
                }
                if (book.getCopiesOnLoan()>popularBooks.get(i).getCopiesOnLoan()){
                    if(popularBooks.size()==count){
                        popularBooks.remove(count-1);
                    }
                    popularBooks.add(i, book);
                    break;
                }
            }
        }
        return popularBooks.toArray(new Book[count]);
    }

}
