import java.util.Arrays;

public class BookMain {
    public static void main(String[] args) {
        BookCollection bCollection = new BookCollection("BookList.csv");
        System.out.println("Authors:");
        System.out.println(bCollection.getAuthors());

        System.out.println("\nLong Books:");
        System.out.println(bCollection.getLongBooks());

        System.out.println("\nTitle of Book: A Modest Proposal");
        System.out.println(bCollection.getBookByTitle("A Modest Proposal").toString());

        System.out.println("\nMost Popular Books:");
        System.out.println(Arrays.toString(bCollection.mostPopular()));
    }
}
