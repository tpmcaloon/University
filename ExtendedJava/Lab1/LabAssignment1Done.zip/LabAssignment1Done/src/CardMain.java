public class CardMain {
    public static void main(String[] args) {

        String[] suits = {"Clubs", "Hearts", "Diamonds", "Spades"};
        String[] values = {"0","A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

        Hand h;

        System.out.println("Testing High Card");
        h = new Hand();
        h.addCard(new Card(values[7], suits[2]));
        h.addCard(new Card(values[8], suits[3]));
        h.addCard(new Card(values[5], suits[1]));
        h.addCard(new Card(values[11], suits[0]));
        h.addCard(new Card(values[13], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting One Pair");
        h = new Hand();
        h.addCard(new Card(values[7], suits[2]));
        h.addCard(new Card(values[7], suits[3]));
        h.addCard(new Card(values[5], suits[1]));
        h.addCard(new Card(values[6], suits[0]));
        h.addCard(new Card(values[3], suits[2]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Two Pair");
        h = new Hand();
        h.addCard(new Card(values[10], suits[2]));
        h.addCard(new Card(values[10], suits[3]));
        h.addCard(new Card(values[5], suits[1]));
        h.addCard(new Card(values[5], suits[0]));
        h.addCard(new Card(values[3], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Three of a Kind");
        h = new Hand();
        h.addCard(new Card(values[2], suits[2]));
        h.addCard(new Card(values[2], suits[3]));
        h.addCard(new Card(values[2], suits[1]));
        h.addCard(new Card(values[13], suits[0]));
        h.addCard(new Card(values[8], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());


        System.out.println("\nTesting Straight");
        h = new Hand();
        h.addCard(new Card(values[6], suits[1]));
        h.addCard(new Card(values[7], suits[0]));
        h.addCard(new Card(values[8], suits[1]));
        h.addCard(new Card(values[9], suits[2]));
        h.addCard(new Card(values[10], suits[3]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Flush");
        h = new Hand();
        h.addCard(new Card(values[3], suits[1]));
        h.addCard(new Card(values[7], suits[1]));
        h.addCard(new Card(values[9], suits[1]));
        h.addCard(new Card(values[11], suits[1]));
        h.addCard(new Card(values[13], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Full House");
        h = new Hand();
        h.addCard(new Card(values[2], suits[2]));
        h.addCard(new Card(values[2], suits[3]));
        h.addCard(new Card(values[2], suits[1]));
        h.addCard(new Card(values[8], suits[0]));
        h.addCard(new Card(values[8], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Four of a Kind");
        h = new Hand();
        h.addCard(new Card(values[7], suits[2]));
        h.addCard(new Card(values[7], suits[3]));
        h.addCard(new Card(values[7], suits[1]));
        h.addCard(new Card(values[7], suits[0]));
        h.addCard(new Card(values[9], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Straight Flush");
        h = new Hand();
        h.addCard(new Card(values[6], suits[1]));
        h.addCard(new Card(values[7], suits[1]));
        h.addCard(new Card(values[8], suits[1]));
        h.addCard(new Card(values[9], suits[1]));
        h.addCard(new Card(values[10], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());

        System.out.println("\nTesting Royal Flush");
        h = new Hand();
        h.addCard(new Card(values[10], suits[1]));
        h.addCard(new Card(values[11], suits[1]));
        h.addCard(new Card(values[12], suits[1]));
        h.addCard(new Card(values[13], suits[1]));
        h.addCard(new Card(values[1], suits[1]));
        System.out.println(h);
        System.out.println(h.getHandRank());
    }
}
