import javax.swing.*;
import java.awt.*;
import java.util.TreeMap;

public class ChangeCalcGUI extends JFrame {

	ChangeCalcGUI(){

		JPanel panel = new JPanel();
		panel.setBounds(0,0,500,520);
		panel.setLayout(null);
		add(panel);


		JLabel label1 = new JLabel("Enter Price (Pound & Pence): ");
		label1.setBounds(20,20,200,30);
		panel.add(label1);

		JTextField priceText = new JTextField();
		priceText.setBounds(250,20,200,30);
		panel.add(priceText);

		JLabel label2 = new JLabel("Enter The Amount Paid : ");
		label2.setBounds(20,70,200,30);
		panel.add(label2);

		JTextField paidText = new JTextField();
		paidText.setBounds(250,70,200,30);
		panel.add(paidText);

		JButton button = new JButton("Calculate");
		button.setBounds(190,120,120,30);
		panel.add(button);

		JTextArea text = new JTextArea();
		text.setBounds(10,160,460,300);
		text.setEditable(false);
		text.setFont(new Font(Font.MONOSPACED,Font.PLAIN,14));
		panel.add(text);

		setBounds(0,0,500,520);
		setResizable(false);
		setVisible(true);
		setTitle("Change Calculator");

		button.addActionListener(e -> {
			try{
				text.setText("");
				double price = Double.parseDouble(priceText.getText());
				double paid = Double.parseDouble(paidText.getText());
				if (price>0.0 && paid >=price){
					TreeMap<NotesAndCoins, Integer> changeComposition = MainChange.calcChange(price, paid);

					for (NotesAndCoins n : changeComposition.keySet()) {
						if (changeComposition.get(n) != 0) {
							text.append(String.format("%-10s : %-10s\n",n.getName(),changeComposition.get(n)));
						}
					}
				}
				else{
					JOptionPane.showMessageDialog(null,"Invalid Input! Price Should Be Positive Number\nPaid Amount Must Be Greater Then Equal To Price","Invalid Input",JOptionPane.ERROR_MESSAGE);
				}

			}catch (NumberFormatException exp){
				JOptionPane.showMessageDialog(null,"Invalid Input! Enter Non-Empty Numbers Only","Invalid Input",JOptionPane.ERROR_MESSAGE);
			}
		});
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		new ChangeCalcGUI();
	}
}
