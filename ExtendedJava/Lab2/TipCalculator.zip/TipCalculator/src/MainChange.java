import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.TreeMap;

public class MainChange {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		boolean biggerPaid = false;

		double price = 0.00, paid = 0.00;

		while (!biggerPaid) {
			price = getMoneyInput("Enter the price in pounds and pence", in);
			paid = getMoneyInput("Enter the amount paid in pounds and pence", in);
			if (price > paid) {
				System.out.println("You haven't paid enough!");
			} else {
				biggerPaid = true;
			}
		}

		System.out.println("price £" + price);
		TreeMap<NotesAndCoins, Integer> changeComposition = calcChange(price, paid);

		for (NotesAndCoins n : changeComposition.keySet()) {
			if (changeComposition.get(n) != 0) {
				System.out.println(n.getName() + ": " + changeComposition.get(n));
			}
		}

	}

	//takes input from the user and ensures it is a double and returns a double with 2 decimal places
	//Question(String) is the prompt for user input and (in)scanner is collecting user input
	public static double getMoneyInput(String question, Scanner in) {
		boolean validInput = false;
		double amount = 0.00;
		//do this until the user enters a valid double
		while (!validInput) {
			System.out.println(question);
			try {
				amount = in.nextDouble();
				validInput = true;
			} catch (InputMismatchException e) {
				System.out.println("Invalid input try again");
				in.next();
			}
		}
		//return the value entered fixed to 2dp
		return (double) ((int) (amount * 100)) / 100;
	}

	public static TreeMap<NotesAndCoins, Integer> calcChange(double price, double paid) {

		//COMPLETE THIS METHOD!!!
		//This method will return a TreeMap where the key is NotesAndCoins and the value is the number of each denomination to make up the change
		double amount = paid - price;

		TreeMap<NotesAndCoins, Integer> treeMap = new TreeMap<>();

		int rem = (int) (amount/50);
		treeMap.put(NotesAndCoins.POUND50,rem);
		amount = amount%50;

		rem = (int) (amount/20);
		treeMap.put(NotesAndCoins.POUND20,rem);
		amount = amount%20;

		rem = (int) (amount/10);
		treeMap.put(NotesAndCoins.POUND10,rem);
		amount = amount%10;

		rem = (int) (amount/5);
		treeMap.put(NotesAndCoins.POUND5,rem);
		amount = amount%5;

		rem = (int) (amount/2);
		treeMap.put(NotesAndCoins.POUND2,rem);
		amount = amount%2;

		rem = (int) (amount);
		treeMap.put(NotesAndCoins.POUND1,rem);
		amount = amount%1;

		amount = amount*100;

		rem = (int) (amount/50);
		treeMap.put(NotesAndCoins.PENCE50,rem);
		amount = amount%50;

		rem = (int) (amount/20);
		treeMap.put(NotesAndCoins.PENCE20,rem);
		amount = amount%20;

		rem = (int) (amount/10);
		treeMap.put(NotesAndCoins.PENCE10,rem);
		amount = amount%10;

		rem = (int) (amount/5);
		treeMap.put(NotesAndCoins.PENCE5,rem);
		amount = amount%5;

		rem = (int) (amount/2);
		treeMap.put(NotesAndCoins.PENCE2,rem);
		amount = amount%2;

		rem = (int) (amount);
		treeMap.put(NotesAndCoins.PENCE1,rem);

		return treeMap;
	}
}

