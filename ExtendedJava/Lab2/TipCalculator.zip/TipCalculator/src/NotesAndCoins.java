public enum NotesAndCoins {
	PENCE1(1, "1p"),
	PENCE2(2, "2p"),
	PENCE5(5, "5p"),
	PENCE10(10, "10p"),
	PENCE20(20, "20p"),
	PENCE50(50, "50p"),
	POUND1(100, "\u00a31"),
	POUND2(200, "\u00a32"),
	POUND5(500, "\u00a35"),
	POUND10(1000, "\u00a310"),
	POUND20(2000, "\u00a320"),
	POUND50(5000, "\u00a350");


	//how many pence is each constant worth
	private int valueInP;
	//a user-friendly name for the constant
	private String name;


	//add constructors and getters for valueInP and name
	NotesAndCoins(int valueInP, String name) {
		this.valueInP = valueInP;
		this.name = name;
	}

	public int getValueInP() {
		return valueInP;
	}

	public String getName() {
		return name;
	}
}
