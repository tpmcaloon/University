import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class TipCalculator extends JFrame {
	TipCalculator(){

		JPanel panel1 = new JPanel();
		panel1.setPreferredSize(new Dimension(400,50));
		add(panel1);

		JLabel label1 = new JLabel("Price");
		label1.setPreferredSize(new Dimension(150,30));
		panel1.add(label1);

		JTextField priceText = new JTextField();
		priceText.setPreferredSize(new Dimension(150,30));
		panel1.add(priceText);




		JPanel panel2 = new JPanel();
		panel2.setPreferredSize(new Dimension(400,50));
		add(panel2);

		JLabel label2 = new JLabel("Tip (%)");
		label2.setPreferredSize(new Dimension(150,30));
		panel2.add(label2);

		JTextField tipText = new JTextField();
		tipText.setPreferredSize(new Dimension(150,30));
		panel2.add(tipText);




		JPanel panel3 = new JPanel();
		panel3.setPreferredSize(new Dimension(400,50));
		add(panel3);

		JLabel label3 = new JLabel("People");
		label3.setPreferredSize(new Dimension(150,30));
		panel3.add(label3);

		JTextField peopleText = new JTextField();
		peopleText.setPreferredSize(new Dimension(150,30));
		panel3.add(peopleText);




		JPanel panel4 = new JPanel();
		panel4.setPreferredSize(new Dimension(400,50));
		add(panel4);

		JButton calculateButton = new JButton("Calculate");
		calculateButton.setPreferredSize(new Dimension(150,30));
		panel4.add(calculateButton);



		JPanel panel5 = new JPanel();
		panel5.setPreferredSize(new Dimension(400,50));
		add(panel5);

		JLabel result = new JLabel("");
		result.setFont(new Font(Font.MONOSPACED,Font.BOLD,16));
		panel5.add(result);



		setTitle("Tip Calculator");
		setMaximumSize(new Dimension(400,400));
		setMinimumSize(new Dimension(400,400));
		setSize(400,400);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout(FlowLayout.CENTER,0,20));


		calculateButton.addActionListener(e -> {
			try{
				double price = Double.parseDouble(priceText.getText());
				double tip = Double.parseDouble(tipText.getText());
				int num = Integer.parseInt(peopleText.getText());

				if (price>=0.0 && tip >=0.0  && num>0){
					Double each = (price + (price*tip)/100)/num;
					result.setText(String.format("Each person should pay \u00a3%.2f",each));
				}
				else{
					JOptionPane.showMessageDialog(null,"Invalid Input! Enter Positive Numbers Only","Invalid Input",JOptionPane.ERROR_MESSAGE);
				}
			}catch (NumberFormatException exp){
				JOptionPane.showMessageDialog(null,"Invalid Input! Enter Non-Empty Numbers Only","Invalid Input",JOptionPane.ERROR_MESSAGE);
			}
		});

	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		new TipCalculator();
	}
}
