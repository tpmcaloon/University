public class MyMiniList <T> implements MiniList<T> {
	private Object[] objectStore;
	private int listSize;
	public MyMiniList()
	{
		objectStore = (T[]) new Object[10];
		listSize=0;
		
	}
    @Override
    public void add(T element) {
    	if (this.objectStore.length<=this.listSize)
    	{
    		Object[] tempArray=(T[]) new Object[this.objectStore.length*2];
    		for(int i=0; i<this.listSize; i++)
    		{
    			tempArray[i]=this.objectStore[i];
    			
    		}
    		tempArray[listSize]=element;
    		this.listSize++;
    		this.objectStore=tempArray;
    		
    	}
    	else
    	{
    		objectStore[listSize]=element;
    		this.listSize++;
    		
    		
    	}

    }

    @Override
    public T get(int index) {
    	if(!(index>-1 && index<this.listSize))
    	{
    		 return null;
    		
    	}
    	else
    	{
    		return (T) this.objectStore[index];
    	}
    }

    @Override
    public int getIndex(T element) {
    	int index=-1;
    	for(int i=0; i<this.listSize; i++)
    	{
    		if(this.objectStore[i]==element)
    		{
    			index=i;
    			break;
    		}
    	}
        return index;
    }

    @Override
    public void set(int index, T element) {
      if(index>-1 && index<this.objectStore.length)
      {
    	  this.objectStore[index]=element;
      }
    }

    @Override
    public int size() {
        return this.listSize;
    }

    @Override
    public T remove(int index) {
    	if(index>-1 && index<this.listSize)
    	{
    		Object temp=this.objectStore[index];
    		this.objectStore[index]=this.objectStore[this.listSize-1];
    		this.listSize--;
    		return (T) temp;
    	}
    	else
    	{
        return null;
    	}
    }

    @Override
    public boolean remove(T element) {
        for(int i=0;i<this.listSize; i++)
        {
        	if(this.objectStore[i]==element)
        	{
        		
        		this.objectStore[i]=this.objectStore[this.listSize-1];
        		this.listSize--;
        		return true;
        	}
        }
    	return false;
    }
    

    @Override
    public void clear() {
    	
    	this.listSize=0;
    	this.objectStore=(T[]) new Object[0];

    }
}
