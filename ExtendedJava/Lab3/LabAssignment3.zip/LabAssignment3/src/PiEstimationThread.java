

import java.util.Random;

public class PiEstimationThread extends Thread {
	 public static int numberOfDarts = 100_000_000;
	 public void run(){ 
		 Random r = new Random();
		 TotalWithin total=new TotalWithin();
		 for(int i=0; i<numberOfDarts; i++)
			{
		 
		 double x = r.nextDouble();
         double y = r.nextDouble();
         //calculate the distance from the origin (0, 0) darts with a distance less than 1 are within the
         //quarter circle so add these to within
         double dist = Math.sqrt((x*x) + (y*y));
         if(dist < 1)
         {
            total.increaseby_1();
       
         }
			}
		 double estimate1 = (double)total.getTotalWithIn()/numberOfDarts *4;
		 System.out.println("Estimation: "+ estimate1);
		  }

	public static void main(String[] args) {
		PiEstimationThread thread1=new PiEstimationThread();
		PiEstimationThread thread2=new PiEstimationThread();
		PiEstimationThread thread3=new PiEstimationThread();
		PiEstimationThread thread4=new PiEstimationThread();
		
		// thread 1 runing
		System.out.println("....thread 1 runing...");
		thread1.start();
		// thread 2 runing
		System.out.println("....thread 2 runing...");
		thread2.start();
		// thread 3 runing
		System.out.println("....thread 3 runing...");
		thread3.start();
		// thread 4 runing
		System.out.println("....thread 4 runing...");
		thread4.start();

	}

}
