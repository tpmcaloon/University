
public class TotalWithin {
	public int getTotalWithIn() {
		return totalWithIn;
	}

	public void setTotalWithIn(int totalWithIn) {
		this.totalWithIn = totalWithIn;
	}

	private int totalWithIn;
	public TotalWithin()
	{
		this.totalWithIn=0;
	}
	public void increaseby_1()
	{
		this.totalWithIn++;
	}
	

}
