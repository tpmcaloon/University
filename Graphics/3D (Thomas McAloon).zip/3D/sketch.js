let pyramid;
let sand;

function preload()
{
    pyramid = loadImage('assets/pyramid_texture.jpg')
    sand = loadImage('assets/sand_texture.jpg')
}

function setup() {
    createCanvas(1500, 1000, WEBGL);
}

function draw() {
    background(193, 234, 254);

    let locX = mouseX - height / 1.25;
    let locY = mouseY - width / 1.25;
    
    pointLight(250, 250, 250, locX, -1000, -500);    
    camera(2200, -450, -2500, 0, 0, 0, 0, 1, 0)
    //camera(locX, locY, -3000, 0, 0, 0, 0, 1, 0)

    

    
    noStroke();
    texture(sand)
    box(5000, 50, 5000);
    
    translate(0, -450, 0)
    rotateY(0.5)
    texture(pyramid);
    cone(1000, -1000, 5)

    translate(1000, 100,400)
    texture(pyramid);
    cone(700, -700, 5)
    
    translate(-1550, 0, -1050)
    cone(700, -700, 5)

    push()
    translate(2400, 250, 800)
    cone(300, -300, 5)

    translate(-300, 0, -300)
    cone(300, -300, 5)
    
    translate(-300, 0, -300)
    cone(300, -300, 5)
    pop()
}