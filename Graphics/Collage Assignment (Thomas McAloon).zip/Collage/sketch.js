/**
 * Template for making an image collage. Demonstrates compositing, 
 * cropping, filtering, and image blending:
 * 
 * 1. Compositing using blendMode() and tint()
 * 2. Masking using filter() to create a masks,
 *    blend modes to apply them
 * 3. Cropping and scaling using the image() function
 * 4. Cropping and scaling using shapes and texture()
 */


///--- THE ASSIGNMENT ---------------------------
///
/// You will use the collage or photomontage art technique
/// to gain experience using different imaging techniques,
/// so you can understand what they do and how to apply them 
/// in practice.
/// 
/// 0. Have a conversation with a group member about their hobbies,
///  dreams, etc. and write down some keywords (cats, football, activism, etc.). 
/// 1. Find some images to use from public domain or Creative Commons 
///    sources (see below) 
/// 2. Using this sketch for inspiration (good or bad), using those images
///    to make a cut-and-paste collage or 'photomontage'
/// 3. Make sure to use one or more:
///   - filters
///   - blend modes   
///   - copying parts of images (see function drawAngelaEye() below)
///   - for much more advanced copying, trying coping from the image pixels[]
///     array directly onto the canvas, or into a new image.
/// 4. For a more advanced task, try tinting the images according to a colour scheme,
///   and drawing more complex patterns using translate and rotate.
/// 5. Another advanced task is to use shape and texture coordinates
///   to crop and scale your composite images.
/// 
/// NOTES: This is fun if you use images with transparent backgrounds, 
///   like nose.png. You can use GIMP or PhotoShop or other means to edit the 
///   images, although this isn't a requirement.


/// ----- 1. Put some images here! -------------
/// You need to download them from somewhere, try and find
/// a source that has proper usage rights (Creative Commons 
/// non-commercial, or public domain)

/// ---- MAKE SURE TO PUT THE URL YOU FOUND THEM AT HERE, 
/// ---- OR LET US KNOW THE SOURCE ------------------------

// Moon Landing Apollo 11
// source: https://theconversation.com/5-moon-landing-innovations-that-changed-life-on-earth-102700 
let moonImage; 

// Eiffel Tower
// Source: https://unsplash.com/photos/UzagqG756OU
let eiffelImage;

// UFO
// Source: https://www.forbes.com/sites/ericmack/2020/04/29/the-navy-just-released-ufo-videos-that-demand-another-look/
let ufoImage;

///-------------------------------------------------------
/// --- MASKING-------------------------------------------
///
/**
 * Turn an image into a black and white mask using a threshold
 * filter to make all lighter pixels white and all darker ones black.
 * This permanently modifies the image, in memory!
 * 
 * @param {p5.Image} srcImage Source image to turn into a black/white mask image 
 */
function createMask(srcImage) {
  //-------------------------------------------------------
  // --- FILTERING ----------------------------------------
  // filter images -- must be done AFTER create canvas
  // https://p5js.org/reference/#/p5/filter
  //
  srcImage.filter(THRESHOLD); // turn white/black only
}

function createBG(srcImage) {
  //-------------------------------------------------------
  // --- FILTERING ----------------------------------------
  // filter images -- must be done AFTER create canvas
  // https://p5js.org/reference/#/p5/filter
  //
  srcImage.filter(POSTERIZE, 3); // make this image slightly blurry
}


/// --- PRELOAD ------------------------
/// This is useful to load an image  or do a task that is important to run
/// *before* the sketch is loaded. preload() runs once *before* setup

function preload() {  
  // load images from the assets folder
    
    moonImage = loadImage('assets/moon.jpg');
    
    eiffelImage = loadImage('assets/eiffel.jpg')

    ufoImage = loadImage('assets/ufo.jpg')

 //pixelDensity(1); // if you are on a very large screen, this can
  // help your images scale to the proper size when drawn
}


///
/// Setup -------------------------
///

function setup() {  

  createCanvas(moonImage.width, moonImage.height); // create a canvas EXACTLY the size of our image
  // Allows me to edit the background using filters
  createBG(moonImage);

  // turn the eiffel into a mask image:
  createMask(eiffelImage);


  // Gives a grey look to the ufo
  ufoImage.filter(GRAY); // opposite colors
}


/**
 * This is a slightly more convenient way to
 *  draw Angela's eye on the canvas.
 * 
 * @param {Number} x center coordinate on canvas to start drawing 
 * @param {Number} y center coordinate on canvas to start drawing 
 * @param {Number} w (optional) width of image to draw on canvas 
 * @param {Number} h (optional) height of image to draw on canvas
 */
function drawUFO(x,y, w,h)
{
  // https://p5js.org/reference/#/p5/image

  image(ufoImage, x,y, // subtracting 1/2 the dimensions 
                             // centers the image
                w,h,              
                350,165, // start coordinates of her left eye 
                542,185 // width and height of eye    
    );
}



/**
 * Draw a mask image onto the screen using SCREEN blend mode.
 * This means the black parts of this image will white out the
 * pixels below it, and the white parts of this image will let the 
 * pixels below show through unaltered.
 * 
 * @param {p5.Image} img Mask image
 * @param {Number} x 
 * @param {Number} y 
 * @param {Number} w 
 * @param {Number} h 
 */
function drawMask(img, x, y, w, h){
    // or try screen
    blendMode(SCREEN);
    imageMode(CENTER); // draw using center coordinate
    image(img, x, y, w, h);
}

///-----------------------------
///--- DRAW --------------------
///-----------------------------

function draw() {

  tint(255,255); // reset tint to full color and no transparency

  // make it so images don't blend, they replace what is under them
  blendMode(REPLACE);

  imageMode(CORNER);
  // draw the image to fill the canvas exactly
  image(moonImage, 0, 0); 

  // draw the mask image onto the background image
  drawMask(eiffelImage, width/2.5, height/3, width/1.5, height/1.5);
  
  // blend using transparency (alpha)
  blendMode(BLEND);
  colorMode(RGB);

  tint(255,180); // make everything after this a little transparent

  imageMode(CORNER);

  // draw cropped eyes
  drawUFO(width - 600, 25, 442,185);
  drawUFO(width - 400, 250, 330,140);
  drawUFO(width - 300, height/3, 300,120);


  // Draw upside-down eyes.
 
  // Gene Kogan has a nice explanation: https://genekogan.com/code/p5js-transformations/


  // use transparency again
  blendMode(BLEND);

} // end draw()
