let moonLandImage;
let earthImage;
let alienImage;

// just number var i use for the 'effect' control
var numbHeight;
var numbWidth;


// Preload image first so we can draw in setup
function preload() {
    moonLandImage = loadImage('assets/MoonLanding.jpg'); // Load the image  
    earthImage = loadImage('assets/earth.jpg')
    alienImage = loadImage('assets/alien.jpg')
}


function setup() {
  createCanvas(700, 335); //Same Size as Main Image
    
  // Displays the original image at its actual size at point (0,0)
    image(moonLandImage, 0, 0);
    image(earthImage, 0, 0);
    image(alienImage, 0, 0);
}

function draw() {
    
  //First for loop with blend mode DODGE
  for (let count = 0; count < 3; count++) {
      drawRandomImageSection(moonLandImage);
      drawRandomImageSection(earthImage);
      drawRandomImageSection(alienImage);
      blendMode(DODGE);
  }

  //Second for loop with blend mode DIFFERENCE
  for (let count = 0; count < 2; count++) {

      drawRandomImageSection(moonLandImage);
      drawRandomImageSection(earthImage);
      drawRandomImageSection(alienImage);
      blendMode(DIFFERENCE);
  }

  //Third for loop with blend mode SOFT_LIGHT
  for (let count = 0; count < 1; count++) {
      drawRandomImageSection(moonLandImage);
      drawRandomImageSection(earthImage);
      drawRandomImageSection(alienImage);
      blendMode(SOFT_LIGHT);
  }
}

/**
 * draw a random part of an image at a random place on the screen
 * {p5.Image} img Image to draw
 */
function drawRandomImageSection(img) {

  // Make this work to draw smaller parts of this 
  // image using random numbers for location, width, height, then:

  //--------------------------------
  // More things to do:
  // 1. Keep aspect ratio (width/height)?
  // 2. Cycle through blend modes?
  // 3. Use slightly less random patterns?


  //Declared randHeight and randWidth for ease. Also put height/width - numbheight/width to be able to manipulate the glitch effect
  let randHeight = random(height - numbHeight);
  let randWidth = random(width - numbWidth);


  let sourceX = randWidth; //???
  let sourceY = randHeight; //???
  let sourceWidth = 0; //???
  let sourceHeight = 0; //???

  let destX = 0; //???
  let destY = 0; //???
  let destWidth = 0; //???
  let destHeight = 0; //??\


  // Displays the image
  image(img, sourceX, sourceY, sourceWidth, sourceHeight, destX, destY, destWidth, destHeight);

  //Hover function

  if ((mouseX > width - 60) && (mouseX < width) && //if the mouse is within the hover boundary, the height is added to by 1 and the width by 0.1
    (mouseY > 0) && (mouseY < 60)) {
    numbHeight += 1;
    numbWidth += 0.1;
  } else {
    numbHeight =300;
    numbWidth = 700;
  }
  rect(width - 60, 0, 60, 60);
  fill(255);
  text("HOVER", width - 50, 60, 100, 100);
}