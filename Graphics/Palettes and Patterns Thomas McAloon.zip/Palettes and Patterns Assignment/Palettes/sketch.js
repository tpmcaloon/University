///
/// Generating computational pallettes.
/// by Thomas McAloon
//
/// - Demonstrating how to use HSB to create pallettes.
/// - Use this as a template for your assignment.


/// Different pallettes are implemented in separate functions
/// so you can choose which to run in your main draw() loop.
/// Each one takes in a start x and y coordinate and the size
/// of the pallette to draw on the screen, so you can draw 
/// multiple pallettes at the same time in different areas.

///---------------------------------------------------------
///---------------YOUR TASK-----------------------------------
///---------------------------------------------------------

/// 1. Experiment with drawMonochromaticPallette() to see what it does
/// 2. Make a modified version of drawMonochromaticPallette() to use
///    that uses brightness AND saturation
/// 3. Experiment with drawAnalogousPallette()
/// 4. Make another version of drawAnalogousPallette() using different
///    colour intervals.
/// 5. Create another pallette function using another system. See
///    class readings and 
///    http://printingcode.runemadsen.com/lecture-color/



///---------------------------------------------------------

// A monochromatic color scheme using fixed intervals
// of brightness for a specific hue and saturation.
// For a more advanced version, try changing *both* brightness
// and saturation.

/**
 * @param {Number} hue Hue angle for this color range, from 0-359
 * @param {Number} startX Start x coordinate for pallette
 * @param {Number} startY Start y coordinate for pallette
 * @param {Number} size Size of pallette in pixels
 */
function drawMonochromaticPallette(hue, startX, startY, size)
{
  let numberOfColors = 10; // number of colors in this pallette
  let saturation = 80; // how "colorful" or gray this color is, from 0-100
  let maxBrightness = 80; // maximum brightness value

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    let currentBrightness = maxBrightness * colorIndex/numberOfColors;
    let currentColor = color(hue, saturation, currentBrightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, swatchSize, swatchSize);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}


///---------------------------------------------------------
/// Fix this function!
///---------------------------------------------------------

// Analogous colors. This is a polychromatic color scheme using
// fixed intervals of changing hue angles to generate a pallette
// of multiple hues (colors) that are close to one another.
//
// In other words, to create a pallette of 6 colours, start with
// a hue angle (say 0) and increase it by a fixed amount (say
// 30 degrees) 6 times to create 6 different color swatches.    

/**
 * @param {Number} hue starting hue angle for this color range, from 0-359
 * @param {Number} startX Start x coordinate for pallette
 * @param {Number} startY Start y coordinate for pallette
 * @param {Number} size Size of pallette in pixels
 */
function drawAnalogousPallette(hue, startX, startY, size)
{
  let numberOfColors = 10; // number of colors in this pallette
  let saturation = 80; // how "colorful" or gray this color is, from 0-100
  let brightness = 80; // brightness value, form 0-100 (black to white)
  let hueInterval = 10; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, swatchSize, swatchSize);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}

function drawTriadPallette(hue, startX, startY, size)
{
  let numberOfColors = 3; // number of colors in this pallette
  let saturation = 80; // how "colorful" or gray this color is, from 0-100
  let brightness = 80; // brightness value, form 0-100 (black to white)
  let hueInterval = 120; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, swatchSize, swatchSize);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}

function drawSquarePallette(hue, startX, startY, size)
{
  let numberOfColors = 4; // number of colors in this pallette
  let saturation = 80; // how "colorful" or gray this color is, from 0-100
  let brightness = 80; // brightness value, form 0-100 (black to white)
  let hueInterval = 90; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, swatchSize, swatchSize);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}

function drawComplementaryPallette(hue, startX, startY, size)
{
  let numberOfColors = 2; // number of colors in this pallette
  let saturation = 80; // how "colorful" or gray this color is, from 0-100
  let brightness = 80; // brightness value, form 0-100 (black to white)
  let hueInterval = 180; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, swatchSize, swatchSize);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}


///-------------------------------------------
///----------SETUP----------------------------
///-------------------------------------------

function setup() {

  /// You can change the size of your drawing canvas if needed!
  createCanvas(1200, 800);
  
  // We can use HSB mode as follows 
  // from (https://p5js.org/reference/#/p5/colorMode):
  // Setting colorMode(HSB) lets you use the HSB system instead.
  // By default, this is colorMode(HSB, 360, 100, 100, 1). 
  // You can also use HSL instead of HSB.

  colorMode(HSB); 
}

///-------------------------------------------
///----------DRAW----------------------------
///-------------------------------------------

/// draw the pallettes.

function draw() {

  background(0);
    
    
//Monochromatic Color Palette-------------------------------------------------------------------------------------------
//Monochrome means the presentation of a single color in different shades.
//The Hue interval is very small and the colour stays in one third of the spectrum.
    

  let hue = 0;


  // Label the pallette. See https://p5js.org/reference/#/p5/text
  fill(180); // gray
  textSize(24);
  text("Monochromatic with hue = " + hue, 10, 48-12);

  // draw with hue = 160
  drawMonochromaticPallette(hue, 10, 48, 200);

    
    
  hue = 125; // update hue for next pallette

  fill(180); // gray
  textSize(24);
  text("Monochromatic with hue = " + hue, 10, 128-12);
  // draw with hue = 220
  drawMonochromaticPallette(hue, 10, 128, 200);


    
    
  /// draw other pallettes below -- possibly resize your canvas.

  hue = 220; // update hue for next pallette

  fill(180); // gray
  textSize(24);
  text("Monochromatic with hue = " + hue, 10, 228-12);
  // draw with hue = 220
  drawMonochromaticPallette(hue, 10, 228, 200);
    
    
//Analogous Color Palette-----------------------------------------------------------------------------------------------
//Analogous colors means the color grouping has similarities.
//The colurs carry across the spectrum but is grouoed in small intervals so there is a gradual change.
    
  currentHue = 0; // update hue for next pallette  
    
  fill(180); // gray
  textSize(24);
  text("Analogous with hue = " + currentHue, 10, 328-12);
  // draw with hue = 220
  drawAnalogousPallette(currentHue, 10, 328, 200);
    
    
  currentHue = 125; // update hue for next pallette  
    
  fill(180); // gray
  textSize(24);
  text("Analogous with hue = " + currentHue, 10, 428-12);
  // draw with hue = 220
  drawAnalogousPallette(currentHue, 10, 428, 200);
    
    
  currentHue = 220; // update hue for next pallette  
    
  fill(180); // gray
  textSize(24);
  text("Analogous with hue = " + currentHue, 10, 528-12);
  // draw with hue = 220
  drawAnalogousPallette(currentHue, 10, 528, 200);
    
   
//Triad Color Palette---------------------------------------------------------------------------------------------------
//A triadic color scheme is comprised of three colors evenly spaced on the color wheel.
//This palette consists of 3 colours spread with an 85 hue interval (360/3).
    
  currentHue = 0;


  // Label the pallette. See https://p5js.org/reference/#/p5/text
  fill(180); // gray
  textSize(24);
  text("Triad with hue = " + currentHue, 400, 48-12);

  // draw with hue = 160
  drawTriadPallette(currentHue, 400, 48, 200);

    
    
  currentHue = 125; // update hue for next pallette

  fill(180); // gray
  textSize(24);
  text("Triad with hue = " + currentHue, 400, 160-12);
  // draw with hue = 220
  drawTriadPallette(currentHue, 400, 160, 200);


    
    
  /// draw other pallettes below -- possibly resize your canvas.

  currentHue = 220; // update hue for next pallette

  fill(180); // gray
  textSize(24);
  text("Triad with hue = " + currentHue, 400, 280-12);
  // draw with hue = 220
  drawTriadPallette(currentHue, 400, 280, 200);
    

//Sqaure Color Palette--------------------------------------------------------------------------------------------------
//A Square color scheme is a four-color combination consisting of a base color and three colors that are 90 degrees apart from the base color.
//This palette consists of 4 colours spread with an 56 hue interval (255/4).
    
  currentHue = 0; // update hue for next pallette  
    
  fill(180); // gray
  textSize(24);
  text("Square with hue = " + currentHue, 400, 400-12);
  // draw with hue = 220
  drawSquarePallette(currentHue, 400, 400, 200);
    
    
  currentHue = 125; // update hue for next pallette  
    
  fill(180); // gray
  textSize(24);
  text("Square with hue = " + currentHue, 400, 500-12);
  // draw with hue = 220
  drawSquarePallette(currentHue, 400, 500, 200);
    
    
  currentHue = 220; // update hue for next pallette  
    
  fill(180); // gray
  textSize(24);
  text("Square with hue = " + currentHue, 400, 600-12);
  // draw with hue = 220
  drawSquarePallette(currentHue, 400, 600, 200);
  
    
  
//Complementary Color Palette-------------------------------------------------------------------------------------------
//A Complementary color palette consists of two colors that are opposite each other on the color wheel.
//This palette consists of 2 colours spread with an 112 hue interval (255/2).
    
  currentHue = 0;


  // Label the pallette. See https://p5js.org/reference/#/p5/text
  fill(180); // gray
  textSize(24);
  text("Complementary with hue = " + hue, 800, 48-12);

  // draw with hue = 160
  drawComplementaryPallette(hue, 800, 48, 200);

    
    
  hue = 125; // update hue for next pallette

  fill(180); // gray
  textSize(24);
  text("Complementary with hue = " + hue, 800, 188-12);
  // draw with hue = 220
  drawComplementaryPallette(hue, 800, 188, 200);

     
    
  hue = 255; // update hue for next pallette

  fill(180); // gray
  textSize(24);
  text("Complementary with hue = " + hue, 800, 328-12);
  // draw with hue = 220
  drawComplementaryPallette(hue, 800, 328, 200);

}