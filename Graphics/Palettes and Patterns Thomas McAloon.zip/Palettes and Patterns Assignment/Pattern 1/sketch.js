/// Graphics: Noisy Pattern
/// by Evan Raskob <e.raskob@gold.ac.uk>
/// Dec. 2020
//
/// Draw a pattern of slightly noise dots in a line
///


// array of dots' x positions
var dots_x;

function setup() {
    
    createCanvas(720, 500);
    colorMode(HSB) //Sets color mode to Hue Saturation Brightness
    regularRandomDots(); // see below
}

function draw() {
  background(220);

  // draw dots in array
  for (var i=0; i < dots_x.length; i++) {
      
      fill(0)
      textSize(25)
      text('Hue', 10, 60)
      noStroke()
      fill(dots_x[i]/2, 80, 80) //fill uses the position of the dots as Hue value
      ellipse(dots_x[i], 100, 50,50) //draws the dots

      fill(0)
      textSize(25)
      text('Saturation', 10, 160)
      fill(mouseX/2, dots_x[i]/7.2, 80) //fill uses the position of the dots as Saturation Value & mouseX for Hue Value
      ellipse(dots_x[i], 200, 50,50) //draws the dots
      
      fill(0)
      textSize(25)
      text('Brightness', 10, 260)
      fill(mouseX/2, 80, dots_x[i]/7.2) //fill uses the position of the dots as Brightness Value & mouseX for Hue Value
      ellipse(dots_x[i], 300, 50,50) //draws the dots

      fill(0)
      textSize(25)
      text('Saturation & Brightness', 10, 360)
      fill(mouseX/2, dots_x[i]/7.2, dots_x[i]/7.2) //fill uses the position of the dots as Saturation and Brightness Values & mouseX for Hue Value
      ellipse(dots_x[i], 400, 50,50) //draws the dots

  }  
}

//
// create regular random dots in a line
// 
function regularRandomDots()
{
  dots_x = []; // clear array
  
  // Place dots 1/10 the width of the screen, starting 1/10 width of screen
  // That means we can only draw 9 dots!
  for (var i=0; i < 9; i++) {
     var spacing = width/10;
     var start_x = width/10;
    
     var x = i*spacing + start_x; // new x position
    
     // add some noise to the x position
     x = x + random( -spacing/5, spacing/5);
    
    // put x position into dots_x array
    dots_x.push(x);
  }
}

//
// Create new positions when mouse is clicked
//
function mouseClicked() {
  regularRandomDots();
}
