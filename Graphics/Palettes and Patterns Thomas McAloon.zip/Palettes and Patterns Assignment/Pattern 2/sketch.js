/// Graphics: Noisy Pattern
/// by Evan Raskob <e.raskob@gold.ac.uk>
/// Dec. 2020
//
/// Draw a pattern of slightly noise dots in a line
///

function drawSliderPalletteHue(hue, startX, startY, size)
{
  let numberOfColors = 360; // number of colors in this pallette
  let saturation = 80; // how "colorful" or gray this color is, from 0-100
  let brightness = 80; // brightness value, form 0-100 (black to white)
  let hueInterval = 1; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, 100, 60);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}


function drawSliderPalletteBrightness(hue, startX, startY, size)
{
  let numberOfColors = 360; // number of colors in this pallette
  let saturation = 80 // how "colorful" or gray this color is, from 0-100
  let brightness = mouseY/7.2; // //Uses Mouse Y position to determine the Brightness
  let hueInterval = 1; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, 100, 60);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}

function drawSliderPalletteSat(hue, startX, startY, size)
{
  let numberOfColors = 360; // number of colors in this pallette
  let saturation = mouseX/7.2; // //Uses Mouse X position to determine the Saturation
  let brightness = 80; // brightness value, form 0-100 (black to white)
  let hueInterval = 1; //??? Experiment with this!

  // size of each of the pallette's color swatches in pixels
  let swatchSize = size/numberOfColors; 

  noStroke();
  rectMode(CORNER);

  push(); // save drawing state
  translate(startX,startY); // move to start x,y position

  for (let colorIndex=0; colorIndex < numberOfColors; colorIndex++)
  {
    ///-------------------------------------------
    ///----------FIXME----------------------------
    ///-------------------------------------------
    ///
    /// Make this line of code work properly
    let currentHue = hue + hueInterval * colorIndex;
    ///-------------------------------------------

    let currentColor = color(currentHue, saturation, brightness);
    
    // draw color square
    fill(currentColor);
    rect(0,0, 100, 60);
    
    // move drawing cursor to next position for next loop
    translate(swatchSize,0);
  }

  pop(); // return to original drawing state
}

// array of dots' x positions
var dots_x;

function setup() {
  createCanvas(720, 600);
  
  regularRandomDots(); // see below
    
    colorMode(HSB)
}

function draw() {
    background(220);
    fill(20);
    strokeWeight(10)
    
    currentHue = 0; // update hue for next pallette  
    
    fill(0)
    textSize(25)
    text('Hue (Left & Right)', 10, 25)
    drawSliderPalletteHue(currentHue, 0, 30, 720);//Draw the Slider Pallette Hue
      
    fill(0)
    textSize(25)
    text('Saturation (Left & Right)', 10, 125)
    drawSliderPalletteSat(currentHue, 0, 130, 720);//Draw the Slider Pallette Saturation
      
    fill(0)
    textSize(25)
    text('Brightness (Up & Down)', 10, 225)
    drawSliderPalletteBrightness(currentHue, 0, 230, 720);//Draw the Slider Pallette Brightness

  // draw dots in array
  for (var i=0; i < lines_x.length; i++) {
      
      stroke(lines_x[i]/2, mouseY/6, mouseX/7.2)//Uses Mouse Y position to determine the Saturation & Mouse X position to determine the Brightness
      line(lines_x[i], 300, lines_x[i],590);// Draws the Lines
      
      noStroke()
      fill(mouseX/2, 80, 80)//Uses Mouse X position to determine the Hue
      ellipse(lines_x[i], mouseY, 40, 40)//Draws the Dots (I have purposely drawn the dots so that they can overlap the Palletes for comparisons)

  }  
}

//
// create regular random dots in a line
// 
function regularRandomDots()
{
  lines_x = []; // clear array
  
  // Place dots 1/10 the width of the screen, starting 1/10 width of screen
  // That means we can only draw 9 dots!
  for (var i=0; i < 9; i++) {
     var spacing = width/10;
     var start_x = width/10;
    
     var x = i*spacing + start_x; // new x position
    
     // add some noise to the x position
     x = x + random( -spacing/5, spacing/5);
    
    // put x position into dots_x array
    lines_x.push(x);
  }
}

//
// Create new positions when mouse is clicked
//
function mouseClicked() {
  regularRandomDots();
}
