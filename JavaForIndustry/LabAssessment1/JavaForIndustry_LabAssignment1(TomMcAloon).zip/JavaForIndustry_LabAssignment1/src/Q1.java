public class Q1 {
    public static void main(String[] args) {
        //write your code here to output the employee details

                int id_number = 12345; //Declaring and Initializing int variable
                String name = "Jack Smith "; //Declaring and Initializing string variable
                byte age = 52; //Declaring and Initializing byte variable
                double salary = 27736.80; //Declaring and Initializing double variable
                int yearsTillRetirement = 66 - age; //Declaring and Initializing and Calculating yearsTillRetirement variable
                double hourlyRate = (salary / 52) / 35; //Declaring and Initializing and Calculating hourlyRate variable



        System.out.println("Employee Reference"); //Printing the 'heading' of the output
        System.out.println("----------------------"); //Printing the 'heading' of the output
        System.out.println("ID Number: " + id_number); //Printing the ID Number string and int variable
        System.out.println("Name: " + name); //Printing the Name string and variable
        System.out.println("Age: " + age); //Printing the Age string and int variable
        System.out.println("Salary: " + "£" + String.format("%,.2f",salary)); //Printing the Salary string and double variable
        System.out.println("Years till retirement: " + yearsTillRetirement + " Years"); //Printing the ID Number string and variable
        System.out.println("Hourly Rate: " + "£"+ hourlyRate); //Printing the ID Number string and variable
    }
}
