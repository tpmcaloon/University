public class Q2 {
    public static void main(String[] args) {
        //part 1: display even numbers between 0 and 1000

        int i = 1; //Declaring and Initializing int to be used within the loop
        do {       //Executing a do-while loop
            System.out.println(i * 2); //Outputting Even numbers
            i++; //postfix increment for the loop to run
        } while (i <= 500); //Setting the loop to run 500 times (1000/2)


        //part 2: display odd numbers between 0 and 1000

        int j = 1; //Declaring and Initializing int to be used within the loop
        do {       //Executing a do-while loop
            System.out.println(j * 2 - 1); //Outputting Odd numbers
            j++; //postfix increment for the loop to run
        } while (j <= 500); //Setting the loop to run 500 times (1000/2)


        //part 3: display all the multiples of 4 between 0 and 1000

        int k = 1; //Declaring and Initializing int to be used within the loop
        do {       //Executing a do-while loop
            System.out.println(k * 4); //Outputting multiples of 4
            k++; //postfix increment for the loop to run
        } while (k <= 250); //Setting the loop to run 250 times (1000/4)

        findMultiples(1000); //Calling the method using the condition n:1000
    }

    //part 4: display all the numbers between 1 and 1000 replacing multiples of 3 with Java
    //multiples of 5 with Script and multiples of 3 and 5 with JavaScript

    public static void findMultiples(int n) {
        int x = 3;  //Declaring and Initializing int to keep track of multiples of 3
        int y = 5;  //Declaring and Initializing int to keep track of multiples of 5
        for (int i = 1; i <= n; i++) {
            String s = ""; //Declaring and Initializing an empty String

            // Found multiple of 3
            if (i == x) { //If i = a multiple of 3
                x = x + 3;  //Update next multiple of 3
                s = s + "Java"; //Using empty string to update multiple of 3 to Java
            }

            // Found multiple of 5
            if (i == y) { //If i = a multiple of 5
                y = y + 5;  //Update next multiple of 5
                s = s +  "Script"; //Using empty string to update multiple of 5 to Script
            }

            if (s.equals("")) //If the string remains empty
                System.out.println(i); //Output the next integer
            else System.out.println(s); //Print the string
        }
    }
}