import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {

        //write your code here to calculate the tax of the variable salary, make sure you try multiple values
        // to test your work

        Scanner input = new Scanner(System.in);
        System.out.print("Enter your income: ");

        double salary = input.nextDouble();
        double finalSalary = salary;

        double taxedSalary;
        double taxAmount = 0;


        if(salary > 50000){ //If salary is over £50,000.00 then the tax will be calculated using this embedded if statement
            taxedSalary = salary - 50000;
            taxAmount = taxedSalary * 0.40;
            salary -= taxedSalary;

            if(salary >= 30000 && salary <= 50000){

                taxedSalary = salary - 30000;
                taxAmount = taxAmount + taxedSalary * 0.20;
                salary -= taxedSalary;

            }

            if(salary >= 15000 && salary <= 30000){
                taxedSalary = salary - 15000;
                taxAmount = taxAmount + taxedSalary * 0.05;
                salary -= taxedSalary;

            }

        }

        if(salary >= 30000 && salary <= 50000){ //If salary is over £50,000.00 then the tax will be calculated using this embedded if statement

            taxedSalary = salary - 30000;
            taxAmount = taxAmount + taxedSalary * 0.20;
            salary -= taxedSalary;

            if(salary >= 15000 && salary <= 30000){
                taxedSalary = salary - 15000;
                taxAmount = taxAmount + taxedSalary * 0.05;
                salary -= taxedSalary;
            }

        }

        if(salary >= 15000 && salary <= 30000){
            taxedSalary = salary - 15000;
            taxAmount = taxAmount + taxedSalary * 0.05;
        }

        finalSalary = finalSalary - taxAmount;
        System.out.println("Your income is: " + "£" + String.format("%,.2f", finalSalary));
        System.out.println("Your tax is: " + "£" + String.format("%,.2f", taxAmount));

    }
}