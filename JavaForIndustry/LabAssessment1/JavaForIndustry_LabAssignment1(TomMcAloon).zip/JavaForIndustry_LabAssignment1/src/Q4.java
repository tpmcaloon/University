import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) throws java.io.IOException {
        //write your answer here

        Scanner input = new Scanner(System.in);

        System.out.println("What service do you require? (or press h to hang up)"); //Print menu output
        System.out.println("Select 1 for Current accounts"); //Print menu output
        System.out.println("Select 2 for Credit cards"); //Print menu output
        System.out.println("Select 3 for Loans"); //Print menu output
        System.out.println("Select 4 for Saving accounts"); //Print menu output
        System.out.print(": ");

        String Menu; //Declaring and Initializing int variable for menu selection
        boolean Live;

        do { //Executing a do-while loop

            Menu = input.next();
            Live = true;

            switch (Menu) {
                case "1":
                    System.out.println("Current accounts");
                    break;

                case "2":
                    System.out.println("Credit cards");
                    break;

                case "3":
                    System.out.println("Loans");
                    break;

                case "4":
                    System.out.println("Savings accounts");
                    break;

                case "h":
                    System.out.println("Have a nice day");
                    Live = false;
                    break;

                default:
                    System.out.println("Error, please choose between 1, 2, 3 ,4");
                    System.out.println("Select 1 for Current accounts");
                    System.out.println("Select 2 for Credit cards");
                    System.out.println("Select 3 for Loans");
                    System.out.println("Select 4 for Saving accounts");
                    System.out.print(": ");
            }
        }while(Live == true);
    }
}
