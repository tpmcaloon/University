public class Invoice {
        // Instance Variables
        int id;
        String description;
        int quantity;
        double unitPrice;
        private boolean paid;

        // Getter
        public boolean getPaid(){
            return this.paid;
        }
        // Setter
        public void setPaid(boolean isPaid){
            this.paid = isPaid;
        }

        // Constructor Declaration of Class
        Invoice(int id, String description, int quantity, double unitPrice)
        {
            this.id = id;
            this.description = description;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
            this.paid = getPaid();
        }
        public String toString()
        {
            return "InvoiceItem [ID=" + id + ", Description=" + description
                    + ", Quantity=" + quantity + ", Unit Price=" + unitPrice + ", Paid=" + paid + "]";
        }
    }
