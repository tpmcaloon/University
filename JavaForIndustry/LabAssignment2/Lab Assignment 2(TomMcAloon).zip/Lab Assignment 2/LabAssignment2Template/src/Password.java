import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Password {

    //PASSWORD GENERATOR--------------------------

    public static String generateRandomPassword(int passwordLength, int amountOfNumbers, int amountOfSymbols) {
        Object[][] characterSets = {
                {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'}
        };

        Object[][] numberSets = {
                {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}
        };

        Object[][] symbolSets = {
                {'~', '`', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '-', '+', '=', '{', '[', '}', ']', '|', '/', ':', ';', '<', '>', '.', '?'}
        };

        List<Character> generatedPassword = new ArrayList<>();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (Object[] characters : characterSets) {
            for (int i = 0; i < (passwordLength / 2) - amountOfNumbers + amountOfSymbols; i++) {
                generatedPassword.add((Character) characters[random.nextInt(0, characters.length)]);
            }
        }
        for (int i = 0; i < passwordLength % 2; i++) {
            Object[] characters = characterSets[random.nextInt(0, characterSets.length)];
            generatedPassword.add((Character) characters[random.nextInt(0, characters.length)]);
        }

        for (Object[] numbers : numberSets) {
            for (int i = 0; i < amountOfNumbers; i++) {
                generatedPassword.add((Character) numbers[random.nextInt(0, numbers.length)]);
            }
        }

        for (Object[] symbols : symbolSets) {
            for (int i = 0; i < amountOfSymbols; i++) {
                generatedPassword.add((Character) symbols[random.nextInt(0, symbols.length)]);
            }
        }


        Collections.shuffle(generatedPassword);

        StringBuilder stringBuilder = new StringBuilder();
        generatedPassword.forEach(stringBuilder::append);

        return "Generated Password: " + stringBuilder;
    }

    //PASSWORD CHECKER--------------------------

    public static String passwordChecker(String password) {


        int symbolCount = 0;

        for (int i = 0; i < password.length(); i++) {
            if (password.substring(i, i + 1).matches("[^A-Za-z0-9]")) {
                symbolCount++;
            }

            Pattern numberChecker = Pattern.compile("(?=.*[0-9])");
            Matcher countNumbers = numberChecker.matcher(password);
            int numberCount = 0;
            while (countNumbers.find()) {
                numberCount ++;
            }

            Pattern lowerCaseChecker = Pattern.compile("(?=.*[a-z])");
            Matcher countLowerCase = lowerCaseChecker.matcher(password);
            int lowerCaseCount = 0;
            while (countLowerCase.find()) {
                lowerCaseCount = 1;
            }

            Pattern upperCaseChecker = Pattern.compile("(?=.*[A-Z])");
            Matcher countUpperCase = upperCaseChecker.matcher(password);
            int upperCaseCount = 0;
            while (countUpperCase.find()) {
                upperCaseCount = 1;
            }


            //if it contains less than 8 characters, 1 or fewer symbols, 2 or fewer digits
            if (password.length() <= 8 && symbolCount <= 1 && numberCount <= 2) {
                return "Poor Password";
            }
            //if it contains more than 8 characters, more than 1 symbols, more than 2 digits
            else if (password.length() > 8 && password.length() < 12 && symbolCount >= 1 && numberCount > 2) {
                return "Okay Password";
            }
            //if it contains more than 12 characters, more than 3 symbols, more than 3 digits and a mix of upper & lower case letters
            else if (password.length() > 12 && password.length() < 16 && symbolCount > 3 && numberCount > 3 && (upperCaseCount == 1 && lowerCaseCount == 1)) {
                return "Good Password";
            }
            //if it contains more than 16 characters, more than 4 symbols, more than 4 digits and a mix of upper & lower case letters
            else if (password.length() >= 16 && symbolCount > 4 && numberCount > 4 && (upperCaseCount == 1 && lowerCaseCount == 1)) {
                return "Excellent Password";
            }

        }
        return "Password: " + password;
    }
}

