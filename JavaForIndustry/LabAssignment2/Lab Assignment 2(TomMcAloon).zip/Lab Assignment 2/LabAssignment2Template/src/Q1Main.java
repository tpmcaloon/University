public class Q1Main {

    public static void main(String[] args) {

        Invoice b = new Invoice(1, "Hot Chocolate", 3, 2.56);
        b.setPaid(true);
        System.out.println(b);
        System.out.print("Status: ");
        System.out.println(b.getPaid() ? "Paid" : "Not Paid");

        System.out.println();


        Invoice c = new Invoice(2, "Coffee", 7, 3.18);
        c.setPaid(true);
        System.out.println(c);
        System.out.print("Status: ");
        System.out.println(c.getPaid() ? "Paid" : "Not Paid");
    }
}