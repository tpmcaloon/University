import java.util.Scanner;

public class Q3Main {
    public static void main(String[] args) {

        System.out.println(Password.generateRandomPassword(16, 3, 4));

        Scanner input = new Scanner(System.in);
        System.out.print("Input a password: ");
        String userPassword = input.nextLine();

        System.out.println(Password.passwordChecker(userPassword));

        System.out.println(Password.passwordChecker("t3st@@"));
        System.out.println(Password.passwordChecker("abCde@£&&12345"));
        System.out.println(Password.passwordChecker("p@55w0rdd"));
        System.out.println(Password.passwordChecker("c0mpu3r£@"));
        System.out.println(Password.passwordChecker("123456abCdef&$£@$"));

    }
}
