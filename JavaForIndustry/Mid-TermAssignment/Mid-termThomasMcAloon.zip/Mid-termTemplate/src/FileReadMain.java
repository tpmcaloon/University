import java.io.*;
import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class FileReadMain {
    public static void main(String[] args) throws IOException {

        //Output the following statistics from the file to the terminal. [5 marks]
        File dist = new File("Metamorphosis.txt");
        new Scanner(dist);
        FileInputStream fileInputStream = new FileInputStream(dist);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        String line;
        int characterCount = 0;
        int wordCount = 0;
        int paraCount = 0;
        int sentenceCount = 0;

        while ((line = bufferedReader.readLine()) != null) {
            if (line.equals("")) {
                paraCount += 1;
            } else {
                characterCount += line.length();
                String[] words = line.split("\\s+");
                wordCount += words.length;
                String[] sentence = line.split("[!?.:]+");
                sentenceCount += sentence.length;
            }
        }
        if (sentenceCount >= 1) {
            paraCount++;
        }

        // Length in characters
        System.out.println("Total number of characters = " + characterCount);

        // Number of words
        System.out.println("Total word count = " + wordCount);

        // Number of sentences
        System.out.println("Total number of sentences = " + sentenceCount);

        // Number of paragraphs
        System.out.println("Number of paragraphs = " + paraCount);

        //Word Frequency List--------------------------------------------------

        BufferedReader br = new BufferedReader(new FileReader("Metamorphosis.txt"));
        StringBuilder sb = new StringBuilder();

        String l = br.readLine();
        while (l != null) {
            sb.append(l).append("\n");
            l = br.readLine();
        }

        String fileAsString = sb.toString();
        String wordList = countFrequency(fileAsString);

        String[] writeWordList = wordList.split(" ");

        BufferedWriter writer = new BufferedWriter(new FileWriter("frequencies.txt"));
        writer.write(String.valueOf(writeWordList));

        writer.close();
    }

    private static String countFrequency(String str) {
        Map<String, Integer> mp = new TreeMap<>();

        // Splitting to find the word
        String[] arr = str.split(" ");

        // Loop to iterate over the words
        for (String s : arr) {
            // Condition to check if the
            // array element is present
            // the hash-map
            if (mp.containsKey(s)) {
                mp.put(s, mp.get(s) + 1);
            } else {
                mp.put(s, 1);
            }
        }

        // Loop to iterate over the
        // elements of the map
        for (Map.Entry<String, Integer> entry :
                mp.entrySet()) {
            System.out.println(entry.getKey() +
                    " - " + entry.getValue());
        }
        return str;
    }
}
