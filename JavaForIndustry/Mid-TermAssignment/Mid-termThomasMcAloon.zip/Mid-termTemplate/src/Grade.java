import java.util.ArrayList;

public class Grade {

    private String subject;
    private int score;
    private static char grade;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public Grade(String subject, int score) {
        this.subject = subject;
        this.score = score;
    }

    public static char getLetterGrade(double score){

        if (score >= 70 && score <= 100) {
            grade = 'A';
        }
        else if (score >= 60 && score <= 70) {
            grade = 'B';
        }
        else if (score >= 50 && score <= 60) {
            grade = 'C';
        }
        else if (score >= 40 && score <= 50) {
            grade = 'D';
        }
        else if (score <= 40 && score >= 0) {
            grade = 'F';
        }
        else if (score < 0 || score > 100) {
            grade = 'E';
        }
        return grade;
    }

    public static void main(String[] args) {
        System.out.println(new Grade("programming", 45));
        System.out.println(Grade.getLetterGrade(110));
    }

    @Override
    public String toString() {
        return "Grade{" +
                "subject='" + subject + '\'' +
                ", score=" + score +
                '}';
    }
}
