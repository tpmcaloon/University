import java.util.ArrayList;
import java.util.List;

public class Student {

    private String fName;
    private String lName;
    private String department;
    private int age;
    private String userName;
    private int studentNumber;
    private boolean fullTime;

    // Getter
    public String getFName() {
        return fName;
    }

    // Setter
    public void setFName(String newFName) {
        this.fName = newFName;
    }

    // Getter
    public String getLName() {
        return lName;
    }

    // Setter
    public void setLName(String newLName) {
        this.lName = newLName;
    }

    // Getter
    public String getDepartment() {
        return department;
    }

    // Setter
    public void setDepartment(String department) {
        this.department = department;
    }

    // Getter
    public int getAge() {
        return age;
    }

    // Setter
    public void setAge(int age) {
        this.age = age;
    }

    // Getter
    public String getUserName() {
        return userName;
    }

    // Setter
    public void setUserName(String userName) {
        this.userName = userName;
    }

    // Getter
    public int getStudentNumber() {
        return studentNumber;
    }

    // Setter
    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }

    // Getter
    public boolean getFullTime() {
        return fullTime;
    }

    // Setter
    public void setFullTime(boolean fullTime) {
        this.fullTime = fullTime;
    }

    public Student(String fName, String lName, String department, String userName, int age, int studentNumber, boolean fullTime) {
        this.fName = fName;
        this.lName = lName;
        this.department = department;
        this.age = age;
        this.studentNumber = studentNumber;
        this.fullTime = fullTime;
        this.userName = fName.charAt(0) + lName.substring(0, 4) + Integer.toString(studentNumber).substring(0, 3);
    }

    public static ArrayList<Grade> grades = new ArrayList<>(); // Create an ArrayList object

    public static void main(String[] args) {

    }


    @Override
    public String toString() {
        return "Student{" +
                "fName='" + fName + '\'' +
                ", lName='" + lName + '\'' +
                ", department='" + department + '\'' +
                ", age=" + age +
                ", userName='" + userName + '\'' +
                ", studentNumber=" + studentNumber +
                ", fullTime=" + fullTime +
                ", grades=" + grades +
                '}';
    }
}




