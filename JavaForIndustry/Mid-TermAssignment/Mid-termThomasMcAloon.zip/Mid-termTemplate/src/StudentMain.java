import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;

public class StudentMain {

    private static ArrayList<Student> students = new ArrayList<>(); // Create an ArrayList object

    public static void main(String[] args) {

        System.out.println("Enter one of the following commands:");
        System.out.println("1 - Report of all students");
        System.out.println("2 - Students with a failed module ");
        System.out.println("3 - Average grade for each student");
        System.out.println("4 - Add a new student to the system");

        boolean failedGrade = Student.grades.stream().equals(students);

        String [] name = new String [5];
        Scanner get = new Scanner (System.in);

        Scanner scanChoice = new Scanner(System.in);
        int menuEntry = 0;

        if(scanChoice.hasNextInt())
            menuEntry = scanChoice.nextInt();

        while(menuEntry < 1 || menuEntry > 5){

            System.out.println("Enter \"1\", \"2\", \"3\" or \"4\"");
            if(scanChoice.hasNextInt())
                menuEntry = scanChoice.nextInt();

        }

        switch(menuEntry){
            case 1:
                //do logic
                students.add(new Student("Bert", "Smith", "computing", "", 21, 12345, true));
                Student.grades.add(new Grade("programming", 52));
                Student.grades.add(new Grade("web dev", 63));
                Student.grades.add(new Grade("maths", 76));
                Student.grades.add(new Grade("algorithms", 68));

                students.add(new Student("Olivia", "Green", "Computing", "",19, 23464, true));
                Student.grades.add(new Grade("programming", 73));
                Student.grades.add(new Grade("web dev", 82));
                Student.grades.add(new Grade("maths", 72));
                Student.grades.add(new Grade("algorithms", 66));

                students.add(new Student("Eloise", "Jones", "Computing", "",18, 34744, true));
                Student.grades.add(new Grade("programming", 65));
                Student.grades.add(new Grade("web dev", 63));
                Student.grades.add(new Grade("maths", 37));
                Student.grades.add(new Grade("algorithms", 40));

                students.add(new Student("Ben", "Bird", "Computing", "",42, 34834, false));
                Student.grades.add(new Grade("programming", 55));
                Student.grades.add(new Grade("web dev", 29));
                Student.grades.add(new Grade("maths", 56));
                Student.grades.add(new Grade("algorithms", 38));

                students.add(new Student("Karen", "Brown", "Computing", "",25, 45632, false));
                Student.grades.add(new Grade("programming", 62));
                Student.grades.add(new Grade("web dev", 51));
                Student.grades.add(new Grade("maths", 43));
                Student.grades.add(new Grade("algorithms", 43));
                System.out.println(students);
                break;
            case 2:

                if(failedGrade == false) {
                    System.out.println(students);
                }
                //do logic
                break;
            case 3:
                //do logic
                break;
            case 4:
                //do logic
                for (int i=0; i<name.length; i++) {
                    System.out.println("Enter Name: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println("Enter Department: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println("Enter AGE: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println("Enter Student Number: ");
                    name[i] = get.nextLine();  // Here

                    System.out.println("Enter Grade for First Module: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println("Enter Grade for Second Module: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println("Enter Grade for Third Module: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println("Enter Grade for Forth Module: ");
                    name[i] = get.nextLine();  // Here
                    System.out.println(name.toString());
                break;

                }
        }
    }
}

